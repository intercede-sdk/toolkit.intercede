//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// MyID REST API Client Utilities
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// The top half of this file comprises utility functions for:
// 1. Receiving and processing JWT authentication tokens
//		parseJwt		(internal function)
//		setAuthToken	(called externally to push an auth token into this page)
//
// 2. Communication with the MyID client service to interact with smart cards
//		getCardSN		ask user to insert/select a card
//		loginToCard		prompt user to enter their PIN to logon with the given card
//
// 3. Sample functions calling MyID REST functions
//		getCardInfo
//		getCardDetails
//		getOperator
//		getPersonDetails
//		getPersonPhoto
//
// 4. A couple of functions for launching DSK and SSA  (use unsupported features)
//	  These rely on forced credentials at v11.x so can be used demo only at present
//		launchDSK
//		launchSSA
//
// The lower section of the file contains web page specific rendering functions
// You should adapt these as necessary to suit your rendering needs
// There are some possibly helpful utilities though at the top of the list
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// Globals
//-----------------------------------------------------------------------------------------

var authToken 		= "";
var jsonToken       = "";
var myidSessionID   = "";
var myidSessionGUID = "";
var userGUID 		= "";
var serialNumber 	= "";
var deviceTypeName 	= "";
var restGET 		= {	method: 'GET', headers: {'content-type': 'application/json'}};

//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// Authentication Token Functions
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// OAuth JWT tokens need a bit of pre-processing to make them easy to read in Javascript
//-----------------------------------------------------------------------------------------
function parseJwt(token) {
	var base64Url = token.split('.')[1];
	var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
	var jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
		return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
	}).join(''));

	return JSON.parse(jsonPayload);
};

//-----------------------------------------------------------------------------------------
// This method is called from the Operator Client launcher to pass us the OAuth token
//-----------------------------------------------------------------------------------------
function setAuthToken(token) {
	jsonToken = parseJwt(token);
	authToken = 'Bearer ' + token;
	restGET   = { method: 'GET', headers: {'content-type': 'application/json', 'Authorization': authToken}};

	userGUID  = jsonToken.sub;
	var myidSession = jsonToken.myidSessionId.split(',');
	myidSessionID   = myidSession[0];
	myidSessionGUID = myidSession[1];

	setInner("sessionID",   myidSessionID);
	setInner("sessionGUID", myidSessionGUID);
	document.getElementById("readButton").disabled = false;

	getOperator(userGUID);
//	getCardSN();
}

//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// Client Service Functions
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// Ask the user to insert and select a smart card
//-----------------------------------------------------------------------------------------
function getCardSN() {
	showStatus("");
	websocket = new WebSocket(settings.wsLocation);
	websocket.onopen = function (event) {
		var payload = '{"Session":"","Type":"Applet","Method":"SelectCard"}';
		websocket.send(payload);
	};

	websocket.onmessage = evt => {
		var data = JSON.parse(evt.data);
		showCardSN(data);
		websocket.close(1000);
	};

	websocket.onclose = function (event) {
		if (event.code > 1000) {
			showStatus("Unable to connect to the local device service");
		}
	};
}

//-----------------------------------------------------------------------------------------
// Perform a PIN authentication to the specified card
//-----------------------------------------------------------------------------------------
function loginToCard(serialNumber, deviceTypeName) {
	websocket = new WebSocket(settings.wsLocation);
	websocket.onopen = function() {
		var payload = {	Session: "", Type: "Applet",	Method: "LoginWithSpecificCard",
						Args:    { SerialNumber: serialNumber, DeviceTypeName: deviceTypeName}
		};
		websocket.send(JSON.stringify(payload));
	}

	websocket.onmessage = evt => {
		var data = JSON.parse(evt.data);
		setInner("lockedStatus", data.CardLocked ? "Locked" : (data.Success) ? "Unlocked" : "Unknown");
		getCardInfo(serialNumber, deviceTypeName);
		websocket.close();
	}
}

//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// MyID REST Service Functions
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
function getCardInfo(serialnumber, cardtype) {
	var url = settings.apiLocation + 'devices?sn=' + serialnumber;
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showCardInfo(info))
	.catch(err      => showStatus("MyID connection refused "))
}

//-----------------------------------------------------------------------------------------
function getCardDetails(id) {
	var url = settings.apiLocation + 'devices/' + id;
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showCardDetails(info))
	.catch(err      => showStatus(err))
}

//-----------------------------------------------------------------------------------------
function getOperator(id) {
	var url = settings.apiLocation + 'people/' + id;
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showOperator(info))
	.catch(err      => showStatus(err))
}

//-----------------------------------------------------------------------------------------
function getPersonDetails(id) {
	var url = settings.apiLocation + 'people/' + id;
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showPersonDetails(info))
	.catch(err      => showStatus(err))
}

//-----------------------------------------------------------------------------------------
function getPersonPhoto(href) {
	var url = settings.apiLocation + href;
	fetch(url, restGET)
	.then (response => response.blob())
	.then (image    => showPhoto(image))
	.catch(err      => showStatus(err))
}


//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// Launch Functions - not yet supported in MyID as there is no pass-through authentication
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
function launchDSK() {
	websocket = new WebSocket(settings.wsLocation);
	websocket.onopen = function() {
		appendToLog("\n   Launching DSK 'Reset Card PIN' workflow...");
		var payload = {
			Type:   "Dsk",
			Method: "StartDskWithArgs",
			Args:   {B64Args: btoa("/lw /opid:297")}
		};
		websocket.send(JSON.stringify(payload));
	}

	websocket.onmessage = evt => {
		appendToLog("\n   " + evt.data);
		if (evt.data.match(/Exit Code/)) {
			appendToLog("\n");
			websocket.close();
		}
	}
}

//-----------------------------------------------------------------------------------------
function launchSSA() {
	websocket = new WebSocket(settings.wsLocation);
	websocket.onopen = function() {
		appendToLog("\n   Launching SSA 'Change My Security Phrases' workflow...");
		var payload = {
			Type:   "Ssa",
			Method: "StartSsaWithArgs",
			Args:   {B64Args: btoa("/opid:110")}
		};
		websocket.send(JSON.stringify(payload));
	}
	
	websocket.onmessage = evt => {
		appendToLog("\n   " + evt.data);
		if (evt.data.match(/Exit Code/)) {
			appendToLog("\n");
			websocket.close();
		}
	}
}



//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// Rendering Functions
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// Utilities
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
function setValue(ID, value) {
	var el = document.getElementById(ID);
	if (el !== null) el.value = value;
}
function setInner(ID, value) {
	var el = document.getElementById(ID);
	if (el !== null) el.textContent = value;
}
function setHTML(ID, value) {
	var el = document.getElementById(ID);
	if (el !== null) el.innerHTML = value;
}
//-----------------------------------------------------------------------------------------
function hide(ID) {
	var el = document.getElementById(ID);
	if (el !== null) document.getElementById(ID).style.display = "none";
}
//-----------------------------------------------------------------------------------------
function show(ID) {
	var el = document.getElementById(ID);
	if (el !== null) document.getElementById(ID).style.display = "block";
}
//-----------------------------------------------------------------------------------------
function enable(ID) {
	var el = document.getElementById(ID);
	if (el !== null) document.getElementById(ID).disabled = false;
}


//-----------------------------------------------------------------------------------------
// Adapt the functions below to suit your needs!
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
function showStatus(value) {setInner("status", value);}

//-----------------------------------------------------------------------------------------
function showPersonDetails(info) {
	setInner("dn",      info.account.dn);
	setInner("address", info.address.line1);
	setInner("empid",   info.employeeId);
	setInner("dob",     info.personal.dateOfBirth.substr(0, 10));
	getPersonPhoto(info.photo.href);
}

//-----------------------------------------------------------------------------------------
function showOperator(info) {
	setInner("operatorName",    "  |  Connected as:  " + info.name.fullName);
	hide("operatorLogon");
  //setInner("operatorLogon",  info.logonName);
}

//-----------------------------------------------------------------------------------------
function showCardDetails(info) {
	setInner("fascn", info.fascn.ascii);
	getPersonDetails (info.owner.id);	
	setValue("CurrentPerson", info.owner.id);
}

//-----------------------------------------------------------------------------------------
function showCardInfo(info) {
	if(info.results.length > 0) {
		setInner("cardsn"    ,  info.results[0].sn);
		setInner("cardtype"  ,  info.results[0].dt);
		setInner("cardstatus",  info.results[0].processStatus);
		setInner("owner"     ,  info.results[0].owner);
		setInner("profile"   ,  info.results[0].credProfileName);
		setInner("validfrom" ,  info.results[0].validFrom);
		setInner("validuntil",  info.results[0].validUntil);
		getCardDetails(info.results[0].id);
	} else {
		showStatus("Card not found or out of scope");
	}
}

//-----------------------------------------------------------------------------------------
function showCardSN(data) {
		deviceTypeName = data.DeviceTypeName; 
		serialNumber   = data.SerialNumber;
		setInner("devicetype",   "Type: "          + deviceTypeName);
		setInner("serialnumber", "Serial Number: " + serialNumber  );
		serialNumber = data.SerialNumber;
		enable("analyzeButton"  );
		enable("checkPINButton" );
		enable("launchDSKButton");
		enable("launchSSAButton");
		getCardInfo(serialNumber, deviceTypeName);
}

//-----------------------------------------------------------------------------------------
function showPhoto(image) {
	var photo = URL.createObjectURL(image);
	var el = document.getElementById("photo");
	if (el !== null) el.src = photo;
}

//-----------------------------------------------------------------------------------------
function appendToLog(logEntry) {
	var clientStatusLog = document.getElementById("clientStatusLog");
	if (clientStatusLog !== null) {
		clientStatusLog.value    += logEntry;
		clientStatusLog.scrollTop = clientStatusLog.scrollHeight;
	}
}

//-----------------------------------------------------------------------------------------
function checkPIN() {
	loginToCard(serialNumber, deviceTypeName);
}


