//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// MyID Standalone Authentication Utilities
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// These functions provide a simple means of obtaining a MyID Authentication Token,
// which you can then pass through to authorize REST API calls
// In later versions, you will also be able to use these to authorize DSK and SSA sessions
//
// To use this script you must include these other scripts in your web page (in this order)
//	<script src="https://<your-myid-server>/myid/OperatorClient/appSettings.js"></script>
//	<script src="settings.js"   ></script>
//	<script src="auth/sha256.js"></script>
//	<script src="auth/pkce.js"  ></script>
//	<script src="auth/oauth2.js"></script>
//	<script src="auth/popup.js" ></script>
//	<script src="auth-helper.js"></script>
//
// You will need to adapt the LoginOK and LoginFail functions to suit your web page
// To instigate a logon, just call signIn()
//-----------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------
function signIn() {
  function removeTrailingSlash(url) {
    if (url?.slice(-1) === "/") return url.slice(0, -1);
    return url;
  }

  const target = removeTrailingSlash(window.location.href); // Must match a RedirectUrl in identityServer client config. 
															
  // Settings are defined in settings.js and OperatorClient/appSettings.js
  const config = {
    url: 		settings.authServerLocation, 
    client: 	settings.client,     		
    redirect: 	target,
    scope: 		"myid.rest.basic",			// No need to change this
    width: 		450, 			 			// Width (in pixels) of login popup window. Optional, default: 400
    height: 	350, 			 			// Height (in pixels) of login popup window. Optional, default: 400
    prompt: 	settings.prompt, 			// Force a login prompt whenever dialogue is launched
    disableLocalStorage: true, 	 			// Not supported in this sample
  };

  // Specifying a tokenUrl forces an authCode grant with PKCE (otherwise it will be an implicit grant)
  if (settings.authServerTokenLocation?.length) { config.tokenUrl = settings.authServerTokenLocation; }

  // Launch the OAuth2 logon window and wait for a response
  authorize(config).then(LoginOK, LoginFail); 		
} 

//----------------------------------------------------------------------------------------------------------
// You can add your own successful login code here
//----------------------------------------------------------------------------------------------------------
function LoginOK(result) { 
	setAuthToken(result.token);
	showStatus("MyID Operator logon OK");
}

//----------------------------------------------------------------------------------------------------------
// You can add your own failed login code here
//----------------------------------------------------------------------------------------------------------
function LoginFail(result) { 
	showStatus("MyID Operator logon failed: " + result);
}

//----------------------------------------------------------------------------------------------------------
// Automatically sign-in on loading the page. This requires popup permissions. Best to use a Sign in button.
//----------------------------------------------------------------------------------------------------------
//  signIn();

  