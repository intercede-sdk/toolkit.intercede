//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// MyID REST API Client Utilities
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// The top half of this file comprises utility functions for:
// 1. Receiving and processing JWT authentication tokens
//		parseJwt		(internal function)
//		setAuthToken	(called externally to push an auth token into this page)
//
// 2. Communication with the MyID client service to interact with smart cards
//		getCardSN		ask user to insert/select a card
//		loginToCard		prompt user to enter their PIN to logon with the given card
//
// 3. Sample functions calling MyID REST functions
//		getCardInfo
//		getCardDetails
//		getCardCertificates
//		getCertificate
//		getOperator
//		getPersonDetails
//		getPersonPhoto
//
// 4. A couple of functions for launching DSK and SSA  (these use unsupported features)
//	  These rely on forced credentials at v11.x so can be used demo only at present
//	  We need to upgrade these to use the v12.4 pass-through authentication.
//		launchDSK
//		launchSSA
//
// The lower section of the file contains web page specific rendering functions
// You should adapt these as necessary to suit your rendering needs
// There are some possibly helpful utilities though at the top of the list
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// Globals
//-----------------------------------------------------------------------------------------

var authToken 		= "";
var jsonToken       = "";
var myidSessionID   = "";
var myidSessionGUID = "";
var userGUID 		= "";
var serialNumber 	= "";
var deviceTypeName 	= "";
var restGET 		= {	method: 'GET', headers: {'content-type': 'application/json'}};

//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// Authentication Token Functions
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// OAuth JWT tokens need some pre-processing to make them easy to read in Javascript
//-----------------------------------------------------------------------------------------
function parseJwt(token) {
	var base64Url = token.split('.')[1];
	var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
	var jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
		return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
	}).join(''));

	return JSON.parse(jsonPayload);
};

//-----------------------------------------------------------------------------------------
// This method is called from the Operator Client launcher to pass us the OAuth token
//-----------------------------------------------------------------------------------------
function setAuthToken(token) {
	jsonToken = parseJwt(token);
	authToken = 'Bearer ' + token;
	restGET   = { method: 'GET', headers: {'content-type': 'application/json', 'Authorization': authToken}};

	userGUID  = jsonToken.sub;
	var myidSession = jsonToken.myidSessionId.split(',');
	myidSessionID   = myidSession[0];
	myidSessionGUID = myidSession[1];

	setInner("sessionID",   myidSessionID);
	setInner("sessionGUID", myidSessionGUID);
	document.getElementById("readButton").disabled = false;

	getOperator(userGUID);
	getCardSN();
}

//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// Client Service Functions
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// Ask the user to insert and select a smart card
//-----------------------------------------------------------------------------------------
function getCardSN() {
	showStatus("");
	websocket = new WebSocket(settings.wsLocation);
	websocket.onopen = function (event) {
		var payload = '{"Session":"","Type":"Applet","Method":"SelectCard"}';
		websocket.send(payload);
	};

	websocket.onmessage = evt => {
		var data = JSON.parse(evt.data);
		showCardSN(data);
		websocket.close(1000);
	};

	websocket.onclose = function (event) {
		if (event.code > 1000) {
			showStatus("Unable to connect to the local device service");
		}
	};
}

//-----------------------------------------------------------------------------------------
// Perform a PIN authentication to the specified card
//-----------------------------------------------------------------------------------------
function loginToCard(serialNumber, deviceTypeName) {
	websocket = new WebSocket(settings.wsLocation);
	websocket.onopen = function() {
		var payload = {	Session: "", Type: "Applet",	Method: "LoginWithSpecificCard",
						Args:    { SerialNumber: serialNumber, DeviceTypeName: deviceTypeName}
		};
		websocket.send(JSON.stringify(payload));
	}

	websocket.onmessage = evt => {
		var data = JSON.parse(evt.data);
		setInner("lockedStatus", data.CardLocked ? "Locked" : (data.Success) ? "Unlocked" : "Unknown");
		getCardInfo(serialNumber, deviceTypeName);
		websocket.close();
	}
}

//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// MyID REST Service Functions - Get properties of Cards, Certificates and People
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
function getCardInfo(serialnumber, cardtype) {
// Find the card record given its serial number
	var url = settings.apiLocation + 'devices?sn=' + serialnumber;
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showCardInfo(info))
	.catch(err      => showStatus("MyID connection refused "))
}

//-----------------------------------------------------------------------------------------
function getCardDetails(id) {
// Retrieves card attributes given its GUID
	var url = settings.apiLocation + 'devices/' + id;
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showCardDetails(info))
	.catch(err      => showStatus(err))
}

//-----------------------------------------------------------------------------------------
function getCardCertificates(id) {
// Get a list of certificates on the card
	var url = settings.apiLocation + 'devices/' + id + '/certificates';
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showCertificateList(info))
	.catch(err      => showStatus(err))
}

//-----------------------------------------------------------------------------------------
function getCertificate(id) {
// Get attributes for the given certificate GUID
	var url = settings.apiLocation + 'certificates/' + id ;
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showCertificate(info))
	.catch(err      => showStatus(err))
}

//-----------------------------------------------------------------------------------------
function getOperator(id) {
	var url = settings.apiLocation + 'people/' + id;
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showOperator(info))
	.catch(err      => showStatus(err))
}

//-----------------------------------------------------------------------------------------
function getPersonDetails(id) {
	var url = settings.apiLocation + 'people/' + id;
	fetch(url, restGET)
	.then (response => response.json())
	.then (info     => showPersonDetails(info))
	.catch(err      => showStatus(err))
}

//-----------------------------------------------------------------------------------------
function getPersonPhoto(href) {
	var url = settings.apiLocation + href;
	fetch(url, restGET)
	.then (response => response.blob())
	.then (image    => showPhoto(image))
	.catch(err      => showStatus(err))
}


//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// Launch Functions - Update needed to use the latest MyID pass-through authentication
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
function launchDSK() {
	websocket = new WebSocket(settings.wsLocation);
	websocket.onopen = function() {
		appendToLog("\n   Launching DSK 'Reset Card PIN' workflow...");
		var payload = {
			Type:   "Dsk",
			Method: "StartDskWithArgs",
			Args:   {B64Args: btoa("/lw /opid:297")}
		};
		websocket.send(JSON.stringify(payload));
	}

	websocket.onmessage = evt => {
		appendToLog("\n   " + evt.data);
		if (evt.data.match(/Exit Code/)) {
			appendToLog("\n");
			websocket.close();
		}
	}
}

//-----------------------------------------------------------------------------------------
function launchSSA() {
	websocket = new WebSocket(settings.wsLocation);
	websocket.onopen = function() {
		appendToLog("\n   Launching SSA 'Change My Security Phrases' workflow...");
		var payload = {
			Type:   "Ssa",
			Method: "StartSsaWithArgs",
			Args:   {B64Args: btoa("/opid:110")}
		};
		websocket.send(JSON.stringify(payload));
	}
	
	websocket.onmessage = evt => {
		appendToLog("\n   " + evt.data);
		if (evt.data.match(/Exit Code/)) {
			appendToLog("\n");
			websocket.close();
		}
	}
}



//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// Rendering Functions
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

function pageLoaded() {
// Initialise the page elements
	for (let i=1; i<11; i++) {
		hide("c" + i + "r7"); // certificate DN is not supported at 12.6
	}
	resetAllCertDisplays(-1);
}

//-----------------------------------------------------------------------------------------
// HTML DOM Manipulation Utilities
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
function setValue(ID, value) {
	var el = document.getElementById(ID);
	if (el !== null) el.value = value;
}
//-----------------------------------------------------------------------------------------
function setInner(ID, value) {
	var el = document.getElementById(ID);
	if (el !== null) el.textContent = value;
}
//-----------------------------------------------------------------------------------------
function setImage(ID, src) {
	var el = document.getElementById(ID);
	if (el !== null) el.src = src;
}
//-----------------------------------------------------------------------------------------
function setHTML(ID, value) {
	var el = document.getElementById(ID);
	if (el !== null) el.innerHTML = value;
}
//-----------------------------------------------------------------------------------------
function hide(ID) {
	var el = document.getElementById(ID);
	if (el !== null) document.getElementById(ID).style.display = "none";
}
//-----------------------------------------------------------------------------------------
function show(ID) {
	var el = document.getElementById(ID);
	if (el !== null) document.getElementById(ID).style.display = "block";
}
//-----------------------------------------------------------------------------------------
function showRow(ID) {
	var el = document.getElementById(ID);
	if (el !== null) document.getElementById(ID).style.display = "table-row";
}
//-----------------------------------------------------------------------------------------
function enable(ID) {
	var el = document.getElementById(ID);
	if (el !== null) document.getElementById(ID).disabled = false;
}


//-----------------------------------------------------------------------------------------
// Display the results - Adapt the functions below to suit your needs!
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
function showStatus(value) {setInner("status", value);}

//-----------------------------------------------------------------------------------------
function showPersonDetails(person) {
	setInner("dn",      person.account.dn);	 				setStatusIcon("cardDNicon", 1);
	setInner("empid",   person.employeeId);;	 			setStatusIcon("cardempidicon", ((person.employeeId != "")? 1:-1));
	setInner("dob",     person.personal.dateOfBirth.substr(0, 10));
	getPersonPhoto(person.photo.href);
}

//-----------------------------------------------------------------------------------------
function showOperator(info) {
	setInner("operatorName",    "  |  Connected as:  " + info.name.fullName);
	hide("operatorLogon");
}

//-----------------------------------------------------------------------------------------
function showCardInfo(info) {
// Performs a basic check on the search results before retrieving the full device and owner details
	if(info.results.length > 0) {
		var card = info.results[0];
		getCardDetails(card.id); 				
		getCardCertificates(card.id)
	} else {
		setStatusIcon("overallStatusicon", -1);
		showStatus("Card not found or out of scope");
	}
}

//-----------------------------------------------------------------------------------------
function showCardDetails(card) {
// Displays the attributes of this card
	var overallStatus = 0;
	var processStatus = 0; 
	var issuedOK = 0; 
	var expiryOK = 0; 
	var fascn = card.fascn.ascii;
	
	if (card.processStatus == "Active") processStatus = 1;
	let date1 = new Date();
	let date2 = new Date(card.validity.to);
	let dateDiff = (date2 - date1) / (3600 * 1000 * 24); // Days until expiry (convert from ms)
	if (dateDiff > 0)  expiryOK = -1;                    // Warning
	if (dateDiff > 28) expiryOK = 1;					 // OK
	
	date2 = new Date(card.validity.from);
	dateDiff = (date2 - date1)
	if (dateDiff < 0)  issuedOK = 1;

	setInner("fascn",      (fascn != "")? fascn: "Absent");		setStatusIcon("cardFASCNicon", (fascn != "")? 1:-1);
	setInner("cardsn"    ,  card.sn); 							setStatusIcon("cardsnicon", 1);
	setInner("cardtype"  ,  card.dt); 							setStatusIcon("cardtypeicon", 1);
	setInner("cardstatus",  card.processStatus); 				setStatusIcon("cardstatusicon", processStatus);
	setInner("owner"     ,  card.owner.name); 					setStatusIcon("cardownericon", 1);
	setInner("profile"   ,  card.credProfile.name); 			setStatusIcon("cardprofileicon", 1);
	setInner("validfrom" ,  dateDisplay(card.validity.from));	setStatusIcon("cardissuedicon", issuedOK);
	setInner("validuntil",  dateDisplay(card.validity.to));		setStatusIcon("cardexpiresicon", expiryOK);

	if (issuedOK == 1 && processStatus ==1) overallStatus = expiryOK;
	setStatusIcon("overallStatusicon", overallStatus);
		
	
	getPersonDetails (card.owner.id);	
	setValue("CurrentPerson", card.owner.id);
}

//-----------------------------------------------------------------------------------------
function showCertificateList(info) {
	// Clean up the display
	resetAllCertDisplays(0);
	// Now read each certificate in the list
	for(var c = 0; c < info.results.length; c++) {
		getCertificate(info.results[c].id);
	}	
}

//-----------------------------------------------------------------------------------------
function resetAllCertDisplays(presence) {
	// 'presence' may be -1 (absent) or 0 (unknown)
	for (let i=1; i<11; i++) {
		resetCertDisplay("c" + i, presence); 
	}
}

//-----------------------------------------------------------------------------------------
function resetCertDisplay(container, presence) {
	// 'presence' may be -1 (absent) or 0 (unknown)
	var contID = "cert" + container;
	var statusID = "stat" + container;
	var isPresent = (presence == 0)? "No": "Unknown";
	
	if (presence < 1) {
		setInner(contID + "present", isPresent); 	setStatusIcon(statusID + "present", presence);
		setInner(contID + "id", "");				setStatusIcon(statusID + "id", -1);
		setInner(contID + "policy", "");			setStatusIcon(statusID + "policy", -1);
		setInner(contID + "serialnumber", "");		setStatusIcon(statusID + "serialnumber", -1);
		setInner(contID + "issued", "");			setStatusIcon(statusID + "issued", -1);
		setInner(contID + "expiry", "");			setStatusIcon(statusID + "expiry", -1);
		setInner(contID + "status", "");	 		setStatusIcon(statusID + "status", -1);
		setStatusIcon(statusID, presence);
		hide(container + "r0");
		hide(container + "r1");
		hide(container + "r2");
		hide(container + "r3");
		hide(container + "r4");
		hide(container + "r5");
		hide(container + "r6");
		hide(container + "r7");
	}
}

//-----------------------------------------------------------------------------------------
function showCertificate(info) {
	var certpresent = false;
	var container = "";
	var contID = "";
	var statusID = "";
	var certStat = 0;
	var certIcon = certStatusIcon(info.status);
	setInner("cert1title","PIV Authentication Certificate");
	policy = info.certPolicy;
	container = info.containerName;
	if (container == "" || policy == "Unmanaged Imported") {
		if (policy.indexOf("PIVAuth")  >= 0)   container = "5FC105";
		if (policy.indexOf("CardAuth") >= 0)   container = "5FC101";
		if (policy.indexOf("Sign") 	   >= 0)   container = "5FC10A";
		if (policy.indexOf("Encr")     >= 0)   container = "5FC10B";
		if (policy == "Unmanaged Imported")  { container = "5FC105"; setInner("cert1title","Imported Certificate");} // VSC has a non-PIV container, so just assume this for now
	}
	if (container != "") {
		container = container.substring(0,6);
		container = certNo(container);
		showRow(container + "r1");
		showRow(container + "r2");
		showRow(container + "r3");
		showRow(container + "r4");
		showRow(container + "r5");
		showRow(container + "r6");
	//  showRow(container + "r7");
	
		var expiryOK = 0; 
		let date1 = new Date();
		let date2 = new Date(info.expiryDate);
		let dateDiff = (date2 - date1) / (3600 * 1000 * 24); // Days until expiry
		if (dateDiff > 0)  expiryOK = -1;                    // Warning
		if (dateDiff > 28) expiryOK = 1;					 // OK
		
		statusID = "stat" + container;
		contID   = "cert" + container;
		setInner(contID + "present", "Yes"); 						setStatusIcon(statusID + "present", 1);
		setInner(contID + "id", info.id);							setStatusIcon(statusID + "id", 1);
		setInner(contID + "policy", policy);						setStatusIcon(statusID + "policy", 1);
		setInner(contID + "serialnumber", info.certSerialNo);		setStatusIcon(statusID + "serialnumber", 1);
		setInner(contID + "issued", dateDisplay(info.dateIssued));  setStatusIcon(statusID + "issued", 1);
		setInner(contID + "expiry", dateDisplay(info.expiryDate));	setStatusIcon(statusID + "expiry", expiryOK);
		setInner(contID + "status", certStatus(info.status));		setStatusIcon(statusID + "status", certIcon);
		setInner(contID + "dn", info.userDN);	    				setStatusIcon(statusID + "dn", ((info.userDN != "")?1:-1));
		certStat = expiryOK;
		if (certIcon == 0) certStat = 0;
		if (certStat == 1) certStat = certIcon;
		setStatusIcon(statusID, certStat);
	}
}

//-----------------------------------------------------------------------------------------
function setStatusIcon(ID, stat) {
	setImage(ID, icon(stat));
}

function icon(stat) {
	if (stat  > 0) return "./yes.gif";
	if (stat == 0) return "./no.gif";
	return "./maybe.gif";
}

//-----------------------------------------------------------------------------------------
function certStatus (status) {
	switch (status) {
		case 1:  return "Issued";						break;
		case 2:  return "Pending issuance";				break;
		case 4:  return "Issuance failed";				break;
		case 8:  return "Revoked";						break;
		case 16: return "Submitted for issuance";		break;
		case 32: return "Pending revocation";			break;
		case 64: return "Submitted for  revocation";	break;
	}
	return "Status unknown";
}	

//-----------------------------------------------------------------------------------------
function certStatusIcon (stat) {
	switch (stat) {
		case 1:  return 1;		break;
		case 2:  return -1;		break;
		case 4:  return 0;		break;
		case 8:  return 0;		break;
		case 16: return -1;		break;
		case 32: return 0;		break;
		case 64: return 0;		break;
	}
	return "Status unknown";
}	

//-----------------------------------------------------------------------------------------
function certNo (container) {
// Converts container name to cert table number on screen
	switch (container) {
		case "5FC105": return ("c1");
		case "5FC101": return ("c2");
		case "5FC10A": return ("c3");
		case "5FC10B": return ("c4");
		case "5FC10D": return ("c5");
		case "5FC10E": return ("c6");
		case "5FC10F": return ("c7");
		case "5FC110": return ("c8");
		case "5FC111": return ("c9");
		case "5FC112": return ("c10");
	}
	return("c1");
}	

//-----------------------------------------------------------------------------------------
function dateDisplay(dateIn) {
	return dateIn.replace("T", " at ");
}

//-----------------------------------------------------------------------------------------
function showCardSN(data) {
	deviceTypeName = data.DeviceTypeName; 
	serialNumber   = data.SerialNumber;
	setInner("devicetype",   "Type: "          + deviceTypeName);
	setInner("serialnumber", "Serial Number: " + serialNumber  );
	serialNumber = data.SerialNumber;
	enable("analyzeButton"  );
	enable("checkPINButton" );
	enable("launchDSKButton");
	enable("launchSSAButton");
	getCardInfo(serialNumber, deviceTypeName);
}

//-----------------------------------------------------------------------------------------
function showPhoto(image) {
	var photo = URL.createObjectURL(image);
	var el = document.getElementById("photo");
	if (el !== null) el.src = photo;
}

//-----------------------------------------------------------------------------------------
function appendToLog(logEntry) {
	var clientStatusLog = document.getElementById("clientStatusLog");
	if (clientStatusLog !== null) {
		clientStatusLog.value    += logEntry;
		clientStatusLog.scrollTop = clientStatusLog.scrollHeight;
	}
}

//-----------------------------------------------------------------------------------------
function checkPIN() {
	loginToCard(serialNumber, deviceTypeName);
}


