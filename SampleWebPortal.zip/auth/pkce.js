//---------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------
// OAuth2 PKCE Utility Functions
//---------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------
// PKCE protocol https://tools.ietf.org/html/rfc7636
// Used with OAuth2 authcode grant, ensures that knowledge of the authcode alone cannot be used to obtain the token
// In some environments webcrypto may not be available for hashing, hence using a pure javascript solution to hashing
// Also using webcrypto for hashing requires promises, which interferes with the auth popup creation on some browsers
// Popup blockers see window created 'not as a direct user action' as the crypto digest promise has to complete first
//---------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------
// RFC-7636 defines the character set and length of the Code Verifier
//---------------------------------------------------------------------------------------------------------------
function generateCodeVerifier() {
	var result = "";
	var length = 43;
	var poss = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
	for (var i = 0; i < length; i++) { result += poss.charAt(Math.floor(Math.random() * poss.length)); }
	return result;
}

//---------------------------------------------------------------------------------------------------------------
function codeChallengeFromVerifier(verifier) {
// Challenge is a URL-safe hash of the byte array representation of the verifier string
	var hash = sha256(verifier);
	var codeChallenge = b64URLEncodeHex(hash);
	return codeChallenge;
}

//---------------------------------------------------------------------------------------------------------------
function hexToBase64(str) {
    return btoa(String.fromCharCode.apply(null,
      str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" "))
    );
}

//---------------------------------------------------------------------------------------------------------------
function b64URLEncodeHex(str) {
	var b64 = hexToBase64(str);
	return b64.replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_')
}


/*
//---------------------------------------------------------------------------------------------------------------
// Test function - useful to validate correct behaviour with two reference verifier/challenge values
//---------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------
function testPKCE () {
debugger;
	var verifier  = 'NrQhNbgwZ0wZVnHQ6GkjE5ZP68JQJMSXVihwuFxJSJ0';
	var challenge = codeChallengeFromVerifier(verifier);
	if (challenge != 'DmN5ge8ApfjDrCPOq6KDhSDm4MGIowh0yiRLwQHclN4') console.error("Failed test 1");
		verifier  = 'd9yS6LY9wqmNDSIwPDAHqS8rkldXI5u4j00CjW3mKhs';
		challenge = codeChallengeFromVerifier(verifier);
	if (challenge != 'iyv2w97fYgo-Ahb7jBib7uEcupu0FzWVlHOZzcH0BbY') console.error("Failed test 2");
	return;
}
testPKCE();
*/
