//---------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------
// OAuth2 Logon Authentication Utility Functions
//---------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------
// How to use this library
// 1. Create your Config object:
//  const config = {
//    url: 		"/web-auth/connect/authorize", 		// Auth server end-point to use
//    client: 	"my.client",     		            // ClientID - must match a web-auth/appsettings.json entry
//    redirect: "https://server.com/MainPage.html",	// Where to go after authenticating				
//    scope: 		"myid.rest.basic",			    // Scope of rest authorization. (No need to change this)
//    width: 		450, 			 			    // Width (in pixels) of login popup window. Default: 400
//    height: 	350, 			 			        // Height (in pixels) of login popup window. Default: 400
//    prompt: 	"Authentication promt message", 	// Set a login prompt whenever dialogue is launched
//    disableLocalStorage: true, 	 				// Local storage is not supported in this sample
//    tokenURL: "/web-auth/connect/toekn", 		    // Token server end-point to use
//  };
//
// 2.Launch the OAuth2 logon window and wait for a response callback
//   authorize(config).then(LoginOK, LoginFail); 
//
// Please see the auth-helper.js file as an example of how to use this library		
//---------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------
// Entry point to this library
//---------------------------------------------------------------------------------------------------------------
function authorize(config) {
  return (responseTypeFromConfig(config) === 'code') ? authorizeAuthCode(config) : authorizeImplicit(config)
}

//---------------------------------------------------------------------------------------------------------------
// Internal functions
//---------------------------------------------------------------------------------------------------------------
function queryStringToJSON(search) {      
    var pairs = search.slice(1).split('&');
    var result = {};
    pairs.forEach(function(pair) {
        pair = pair.split('=');
        result[pair[0]] = decodeURIComponent(pair[1] || '');
    });
    return JSON.parse(JSON.stringify(result));
}

//---------------------------------------------------------------------------------------------------------------
function responseToJSON (response) {
  const expiresIn = response.expires_in ? parseInt(response.expires_in): NaN;
  return {
    token: 	   response.access_token,
    expiresAt: !isNaN(expiresIn) ? Date.now() + expiresIn * 1000 : null
  }
}

//---------------------------------------------------------------------------------------------------------------
function uuidv4() {
  return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
    (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
  );
}

//---------------------------------------------------------------------------------------------------------------
// Poll for a PKCE Token AuthCode response
//---------------------------------------------------------------------------------------------------------------
function listenForAuthCode (popup, state, resolve, reject) {
  let search, response;
  try {
    search = popup.location.search;
  } catch (err) { 
    // if authserver is on another domain, it will be trapped here until redirected to main site
    //console.error(err);
  }

  // If authserver is on same domain as main site then search is accessible, 
  if(search) {
    response = queryStringToJSON(search);
    if(response.code === undefined && response.error === undefined) {
      // Auth won't be 'done' until there is a code or an error returned
      // console.error('auth endpoint not redirected back yet');
      response = null;
    }
  }

  if (response) {
    popup.close();
    if (response.state !== state) { reject('Invalid state returned.') }

    if (response.code) {
      const result = {token: response.code, }
      resolve(result);
	  
    } else {
      //console.log("Error in popup response");
      reject(response.error || 'Unknown error.');
    }
	
  } else if (popup.closed) {
    //console.log("Popup was closed - presume the user cancelled it");
	reject('Authentication was cancelled.');
	
  } else {
    setTimeout(function(){listenForAuthCode(popup, state, resolve, reject);}, 100);
  }
}

//---------------------------------------------------------------------------------------------------------------
// Poll for an implicit AuthCode response (not expected to be used for MyID)
//---------------------------------------------------------------------------------------------------------------
function listenForCredentials (popup, state, resolve, reject) {
  let hash;
  try {
    hash = popup.location.hash;
  } catch (err) {
    // if authserver is on another domain, it will be trapped here until redirected to main site
    //console.error(err);
  }

  if (hash) {
    popup.close();
    const response = queryStringToJSON(hash.substr(1));
    if (response.state !== state) { reject('Invalid state returned.') }

    if (response.access_token) {
      resolve(responseToJSON(response));
    } else {
      reject(response.error || 'Unknown error.');
    }
	
  } else if (popup.closed) {
    reject('Authentication windows was closed');
  } else {
    setTimeout(function(){listenForCredentials(popup, state, resolve, reject);}, 100);
  }
}

//---------------------------------------------------------------------------------------------------------------
function responseTypeFromConfig (config) {
  // default to implicit grant unless tokenUrl defined
  if (config.tokenUrl === undefined || config.tokenUrl === null || config.tokenUrl.length === 0) {
    return 'token';
  } else {
    return 'code';   // authcode
  }
}

//---------------------------------------------------------------------------------------------------------------
function tokenFromCode (config, response, codeVerifier) {
  var body = new URLSearchParams();
  body.append('grant_type', 	'authorization_code');
  body.append('code', 			response.token);
  body.append('redirect_uri', 	config.redirect);
  body.append('client_id', 		config.client);
  body.append('code_verifier', 	codeVerifier);
  if(config.clientSecret !== undefined && config.clientSecret) {
    body.append('client_secret', config.clientSecret)
  };
  var bodyText = body.toString();
  
  return fetch(config.tokenUrl,
    { method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
      body: bodyText
    })
    .then(response => {
      if(response.ok) return response;
      throw Error(`Error from token endpoint, status: ${response.status}`);
    })
	.then(response => response.json())
    .then(response => {
      if(response.access_token) {
        return responseToJSON(response);
      } else {
        throw Error(`Unknown error from token endpoint, error ${response.error}`);
      }
    }).catch(e => {
      console.error(e.message);
      return Promise.reject(e.message || 'Unknown error from token endpoint');
    })
}

//---------------------------------------------------------------------------------------------------------------
function authorizeAuthCode (config) {
  const width  = config.width  || 300;
  const height = config.height || 300;
  // Open the popup ASAP (since delays in generating and hashing the code verifier can cause the auth popup to be blocked on some browsers)
  // It points to nothing at first - it will get redirected later
  const popup = openPopup('', 'oauth2', width, height);

  const state = uuidv4();
  const codeVerifier = generateCodeVerifier();
  const challenge = codeChallengeFromVerifier(codeVerifier);
  const authParams = {
    state,
    response_type: 			'code',
    client_id: 				config.client,
    scope: 					config.scope,
    redirect_uri: 			config.redirect,
    code_challenge_method: 	'S256',
    code_challenge: 		challenge,
    prompt: 				config.prompt
  };

  const query = new URLSearchParams(authParams).toString();
  const url = config.url + (config.url.indexOf('?') === -1 ? '?' : '&') + query;

  popup.location.href = url;

  return new Promise((resolve, reject) => listenForAuthCode(popup, state, resolve, reject))
    .then(response => tokenFromCode(config, response, codeVerifier)
    )
}

//---------------------------------------------------------------------------------------------------------------
function authorizeImplicit(config) {
  const state = uuidv4();
  const query = querystring.stringify({
    state,
    response_type: 	'token',
    client_id: 		config.client,
    scope: 			config.scope,
    redirect_uri: 	config.redirect,
    prompt: 		config.prompt
  });
  const url    = config.url + (config.url.indexOf('?') === -1 ? '?' : '&') + query;
  const width  = config.width  || 400;
  const height = config.height || 400;
  const popup  = openPopup(url, 'oauth2', width, height);

  return new Promise((resolve, reject) =>
    listenForCredentials(popup, state, resolve, reject)
  )
}

