//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// Authentication Popup Window Functions
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
const SETTINGS = 'scrollbars=no,toolbar=no,location=no,titlebar=no,directories=no,status=no,menubar=no';

function getPopupLeft(width, height){
  const wLeft = window.screenLeft || window.screenX;
  const left  = wLeft + (window.outerWidth - width)/ 2 ;
  return left;
}

function getPopupTop(width, height){
  const wTop = window.screenTop  || window.screenY;
  const top = wTop + 200;
  return top;
}

function getPopupDimensions(width, height){
  const left = getPopupLeft(width, height);
  const top  = getPopupTop(width, height);
  return `width=${width},height=${height},top=${top},left=${left}`;
}

function openPopup (url, name, width, height) {
  var pop = window.open(url, name, `${SETTINGS},${getPopupDimensions(width, height)}`);
  // Chrome has a habit of ignoring the requested popup location! Need to force it.
  pop.moveTo(getPopupLeft(width, height), getPopupTop (width, height));
  pop.focus(); // Bring it to the front
  return pop;
}

