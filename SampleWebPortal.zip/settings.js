//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
// MyID REST Client Settings
//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// Note: this script adds settings to the variable defined in the server appSettings.js file
// Is is important that the line:
// 	<script src="https://react.domain31.local/myid/OperatorClient/appSettings.js"></script>
// appears BEFORE this setting.js file in the HTML include list
//
// The Operator Client appSettings includes these values.
//  	apiLocation: 				"/rest.core/api",
//  	wsLocation:  				"ws://127.0.0.1:8081/",
//  	authServerLocation: 		"/web.oauth2/connect/authorize",
//  	authServerTokenLocation: 	"/web.oauth2/connect/token",
//  	supportHandCapture: 		false
//-----------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------
// Override or add your own configuration settings in here
//-----------------------------------------------------------------------------------------
settings.apiLocation = "https://react.domain31.local/rest.core/api/"; // Override - absolute URL
settings.client      = "myid.demo";		// Must match a client name in web-auth/appsettings.json
settings.prompt		 = "Sign in to MyID";