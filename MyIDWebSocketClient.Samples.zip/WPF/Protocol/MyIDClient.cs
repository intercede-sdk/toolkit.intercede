//---------------------------------------------------------------------------------------------------------------
// MyIDClient.cs
// =============
//
// The WebSocket plumbing for the MyID WebSocket Client API samples.
//
// Usage:
//
//     using var client = new MyIDClient { Host = "localhost", Port = 1337 };
//     client.Log    += (s, e) => ...;
//     client.Status += (s, e) => ...;
//
//     await client.ConnectAsync(cancel);
//     var outcome = await client.RunAsync("WORKFLOWFROMTOKEN",
//                                         new { token }, stageHandlers, cancel);
//
// `stageHandlers` maps a stage action name to an async function receiving the
// stage message. Return a StageReply to answer the stage, or null if the stage
// advances on its own.
//
// ---------------------------------------------------------------------------
// THIS IS NOT PRODUCTION CODE
// ---------------------------------------------------------------------------
// Deliberately left out, to keep the samples readable:
//   * version negotiation via GET /myidclient/supportedversions,
//   * TLS (wss://) support,
//   * the CheckPinPolicy round-trip before submitting a new PIN,
//   * retrying a stage after an ActionError (we fail instead),
//   * the SaveErrorReport action offered by error stages,
//   * reconnection and general connection-state hardening.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.Protocol
{
    using System.Net.WebSockets;
    using System.Text;
    using System.Text.Json;
    using System.Text.Json.Nodes;

    public sealed class MyIDClient : IDisposable
    {
        // Secrets are masked before anything reaches the Log event
        private static readonly HashSet<string> SecretKeys =
            new(["pin", "newPin", "oldPin", "token", "client_secret", "access_token"],
                StringComparer.OrdinalIgnoreCase);

        private readonly object eventLock = new();
        private readonly Dictionary<string, List<Action<JsonElement>>> eventSubscribers = [];

        // Here we cache every event we see, keyed by eventId,
        // and let stages wait on ids that haven't turned up yet.
        private readonly Dictionary<string, JsonElement> eventsById = [];

        // Used to ensure no concurrent outgoing WebSocket messages.
        private readonly SemaphoreSlim sendSemaphore = new(1, 1);

        private const string Origin = "http://localhost";

        private readonly ClientWebSocket socket = new();

        // Set once the workflow reaches a terminal state, so the close handling
        // knows not to overwrite the outcome the caller just displayed. Written by
        // the caller's thread, read by the receive-loop.
        private volatile bool finished;

        public string Host
        {
            get;
            init;
        } = "localhost";

        public int Port
        {
            get;
            init;
        } = 1337;

        public string ApiVersion
        {
            get;
            init;
        } = "1.x";

        public void Dispose()
        {
            finished = true;

            // Abort rather than a graceful CloseAsync: the workflow is over, nobody
            // is waiting on the handshake, and Dispose must not throw or block.
            socket.Abort();
            socket.Dispose();
            sendSemaphore.Dispose();
        }

        // Raised for every frame in and out, already redacted.
        public event EventHandler<LogEventArgs>? Log;

        // Raised as progress is reported. Detail carries the tertiary busy
        // messages; the client emits no markup of its own, leaving presentation to
        // the sample.
        public event EventHandler<StatusEventArgs>? Status;

        //-----------------------------------------------------------------------------------------------------------
        // The endpoint shape is  ws://<host>:<port>/v<version>/myidclient
        // Note the version comes FIRST and is prefixed with 'v'. The 'x' in "1.x"
        // is a literal character, not a placeholder: it asks for the latest 1.x.
        //-----------------------------------------------------------------------------------------------------------
        public async Task ConnectAsync(CancellationToken cancel = default)
        {
            var url = $"ws://{Host}:{Port}/v{ApiVersion}/myidclient";
            RaiseStatus($"Connecting to {url} ...");

            try
            {
                socket.Options.SetRequestHeader("Origin", Origin);
                await socket.ConnectAsync(new Uri(url), cancel).ConfigureAwait(false);
            }
            catch (WebSocketException ex)
            {
                throw new MyIDException(
                    $"Could not connect to {url}. Check the MyID client is running and that the " +
                    $"port is correct. ({ex.Message})");
            }

            RaiseStatus("Connected.");
        }

        //-----------------------------------------------------------------------------------------------------------
        // Every message is a JSON "envelope": always an `action`, optionally a
        // `routingId` (to answer a specific stage) and a `payload`.
        //-----------------------------------------------------------------------------------------------------------
        private async Task SendAsync(
            string action,
            string? routingId,
            object? payload,
            CancellationToken cancel = default)
        {
            var envelope = new Dictionary<string, object?> { ["action"] = action };

            if (routingId is not null)
            {
                envelope["routingId"] = routingId;
            }

            if (payload is not null)
            {
                envelope["payload"] = payload;
            }

            string json = JsonSerializer.Serialize(envelope, MyIDJson.Options);
            Log?.Invoke(this, new LogEventArgs(LogDirection.Sent, Redact(json)));

            byte[] bytes = Encoding.UTF8.GetBytes(json);

            await sendSemaphore.WaitAsync(cancel);

            try
            {
                await socket.SendAsync(bytes, WebSocketMessageType.Text, true, cancel)
                    .ConfigureAwait(false);
            }
            finally
            {
                sendSemaphore.Release();
            }
        }

        // Reply to a specific open stage. routingId is mandatory on any message
        // targeting a stage.
        private Task ReplyAsync(IncomingMessage stage, StageReply reply, CancellationToken cancel = default)
        {
            return SendAsync(reply.Action, stage.RoutingId, reply.Payload, cancel);
        }

        //-----------------------------------------------------------------------------------------------------------
        // Start an initial action and pump messages until the workflow finishes.
        //
        // Returns the WorkflowComplete payload. Throws MyIDException on ApiError,
        // ActionError, ShowErrorView, or an unexpected close.
        //-----------------------------------------------------------------------------------------------------------
        public async Task<WorkflowCompletePayload> RunAsync(
            string initialAction,
            object? initialPayload,
            IReadOnlyDictionary<string, Func<IncomingMessage, MyIDClient, Task<StageReply?>>> stageHandlers,
            CancellationToken cancel = default)
        {
            var completion = new TaskCompletionSource<WorkflowCompletePayload>(
                TaskCreationOptions.RunContinuationsAsynchronously);

            using CancellationTokenRegistration registration = cancel.Register(() => completion.TrySetCanceled(cancel));

            // The pump parks inside ReceiveAsync, so it needs a token of its own to
            // be woken by when the workflow settles for any other reason.
            using var pumpCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancel);

            Task pump = PumpAsync(stageHandlers, completion, pumpCancellation.Token);

            await SendAsync(initialAction, null, initialPayload, cancel)
                .ConfigureAwait(false);

            try
            {
                return await completion.Task.ConfigureAwait(false);
            }
            finally
            {
                finished = true;
                pumpCancellation.Cancel();
                await pump.ConfigureAwait(false);
            }
        }

        //-----------------------------------------------------------------------------------------------------------
        // The receive loop.
        //
        // Stage handlers are started but NOT awaited here. A handler blocks while
        // it waits for the user, and the pump has to keep reading in the meantime:
        // the card list is revised as readers come and go, and those revisions
        // arrive while the select-card stage is still open. Awaiting the handler
        // inline would deadlock the picker.
        //-----------------------------------------------------------------------------------------------------------
        private async Task PumpAsync(
            IReadOnlyDictionary<string, Func<IncomingMessage, MyIDClient, Task<StageReply?>>> stageHandlers,
            TaskCompletionSource<WorkflowCompletePayload> completion,
            CancellationToken cancel)
        {
            var buffer = new byte[16 * 1024];

            try
            {
                while (socket.State == WebSocketState.Open && !cancel.IsCancellationRequested)
                {
                    string? frame = await ReceiveFrameAsync(buffer, cancel).ConfigureAwait(false);

                    if (frame is null)
                    {
                        // Only worth reporting when the workflow hasn't already
                        // finished - otherwise this would overwrite the outcome the
                        // caller displayed just before tearing the connection down.
                        if (!finished)
                        {
                            completion.TrySetException(new MyIDException(
                                "The client closed the connection before the workflow finished."));
                        }

                        return;
                    }

                    Log?.Invoke(this, new LogEventArgs(LogDirection.Received, Redact(frame)));

                    IncomingMessage? message;

                    try
                    {
                        message = JsonSerializer.Deserialize<IncomingMessage>(frame, MyIDJson.Options);
                    }
                    catch (JsonException ex)
                    {
                        completion.TrySetException(
                            new MyIDException($"Received a frame that was not valid JSON. ({ex.Message})"));
                        return;
                    }

                    if (message is null)
                    {
                        continue;
                    }

                    Dispatch(message, stageHandlers, completion, cancel);

                    if (completion.Task.IsCompleted)
                    {
                        return;
                    }
                }
            }
            catch (OperationCanceledException)
            {
                // The caller cancelled; completion is already faulted.
            }
            catch (Exception ex)
            {
                completion.TrySetException(ex);
            }
        }

        private void Dispatch(
            IncomingMessage message,
            IReadOnlyDictionary<string, Func<IncomingMessage, MyIDClient, Task<StageReply?>>> stageHandlers,
            TaskCompletionSource<WorkflowCompletePayload> completion,
            CancellationToken cancel)
        {
            switch (message.Type)
            {
                case MessageTypes.ShowStage:
                    HandleStage(message, stageHandlers, completion, cancel);
                    break;

                case MessageTypes.EventNotification:
                    CacheEvent(message);
                    break;

                case MessageTypes.BusyStateChanged:
                    // HideBusyMessage carries no payload at all, so dispatch on the
                    // action rather than probing the payload.
                    if (message.Action == Actions.HideBusyMessage)
                    {
                        RaiseStatus(string.Empty);
                    }
                    else
                    {
                        var busy = message.PayloadAs<BusyPayload>();
                        RaiseStatus(busy.PrimaryBusyMessage ?? string.Empty,
                            detail: busy.TertiaryBusyMessages ?? []);
                    }

                    break;

                case MessageTypes.Error:
                    // ApiError   - the request itself was invalid; fatal here.
                    // ActionError - the stage is still open and a corrected reply
                    //               could be sent. The samples don't retry, so this
                    //               is fatal too, but we name it clearly.
                    var error = message.PayloadAs<ErrorPayload>();
                    completion.TrySetException(new MyIDException(
                        $"{message.Action}: {error.ErrorCode ?? error.ErrorMessage ?? "unknown error"}"));
                    break;

                case MessageTypes.WorkflowControl:
                    if (message.Action == Actions.WorkflowComplete)
                    {
                        var outcome = message.PayloadAs<WorkflowCompletePayload>();

                        // A cancelled workflow reports 'success: false' with 'aborted:
                        // true' - this is not considered an error (the user aborted). 
                        if (outcome.IsSuccess || outcome.IsAborted)
                        {
                            if (outcome.IsSuccess)
                            {
                                RaiseStatus("Workflow completed successfully.", StatusKind.Done);
                            }

                            completion.TrySetResult(outcome);
                        }
                        else
                        {
                            completion.TrySetException(new MyIDException(
                                outcome.ErrorMessage ?? "The workflow did not complete successfully."));
                        }
                    }

                    break;
            }
        }

        private void HandleStage(
            IncomingMessage stage,
            IReadOnlyDictionary<string, Func<IncomingMessage, MyIDClient, Task<StageReply?>>> stageHandlers,
            TaskCompletionSource<WorkflowCompletePayload> completion,
            CancellationToken cancel)
        {
            // ShowErrorView is a workflow-level failure. Surface the MyID error code
            // and message rather than letting the pump stall.
            if (stage.Action == Actions.ShowErrorView)
            {
                var payload = stage.PayloadAs<StagePayload>();
                string code = string.IsNullOrEmpty(payload.ErrorCode) ? string.Empty : $" ({payload.ErrorCode})";

                completion.TrySetException(new MyIDException(
                    (payload.ErrorMessage ?? "The workflow reported an error.") + code));
                return;
            }

            if (stage.Action is null || !stageHandlers.TryGetValue(stage.Action,
                    out Func<IncomingMessage, MyIDClient, Task<StageReply?>>? handler))
            {
                completion.TrySetException(new MyIDException(
                    $"Unexpected stage '{stage.Action}'. This sample only handles: " +
                    $"{string.Join(", ", stageHandlers.Keys)}. Check the credential profile configuration."));
                return;
            }

            // Deliberately not awaited - see the comment on PumpAsync.
            _ = Task.Run(async () =>
            {
                try
                {
                    StageReply? reply = await handler(stage, this).ConfigureAwait(false);

                    if (reply is not null)
                    {
                        await ReplyAsync(stage, reply, cancel).ConfigureAwait(false);
                    }
                }
                catch (OperationCanceledException)
                {
                    // The caller is tearing the workflow down.
                }
                catch (Exception ex)
                {
                    completion.TrySetException(ex);
                }
            }, cancel);
        }

        private async Task<string?> ReceiveFrameAsync(byte[] buffer, CancellationToken cancel)
        {
            var builder = new StringBuilder();

            while (true)
            {
                WebSocketReceiveResult result;

                try
                {
                    result = await socket.ReceiveAsync(buffer, cancel).ConfigureAwait(false);
                }
                catch (WebSocketException)
                {
                    return null;
                }

                if (result.MessageType == WebSocketMessageType.Close)
                {
                    return null;
                }

                builder.Append(Encoding.UTF8.GetString(buffer, 0, result.Count));

                if (result.EndOfMessage)
                {
                    return builder.ToString();
                }
            }
        }

        //-----------------------------------------------------------------------------------------------------------
        // The event cache and the stage helpers that build on it.
        //-----------------------------------------------------------------------------------------------------------
        private void CacheEvent(IncomingMessage message)
        {
            if (message.EventId is not { } eventId)
            {
                return;
            }

            List<Action<JsonElement>> subscribers;

            lock (eventLock)
            {
                eventsById[eventId] = message.Payload;

                subscribers = eventSubscribers.TryGetValue(eventId, out List<Action<JsonElement>>? list)
                    ? list.ToList()
                    : [];
            }

            // A card list is revised whenever readers come and go, reusing the same
            // eventId, so notify every subscriber rather than just the first.
            foreach (Action<JsonElement> subscriber in subscribers)
            {
                subscriber(message.Payload);
            }
        }

        // Subscribe to every revision of an event, not just the first. Returns an
        // unsubscribe action.
        private IDisposable OnEvent(string eventId, Action<JsonElement> callback)
        {
            lock (eventLock)
            {
                if (!eventSubscribers.TryGetValue(eventId, out List<Action<JsonElement>>? list))
                {
                    list = [];
                    eventSubscribers[eventId] = list;
                }

                list.Add(callback);
            }

            return new Unsubscriber(() =>
            {
                lock (eventLock)
                {
                    if (eventSubscribers.TryGetValue(eventId, out List<Action<JsonElement>>? list))
                    {
                        list.Remove(callback);
                    }
                }
            });
        }

        // Report whether a stage offers a particular reply action.
        //
        // The set of valid actions is ALWAYS the one the stage advertises in
        // supportedActions - well-known names like "Cancel" are reserved, but are
        // never guaranteed to be offered, so never assume one without checking.
        public static bool StageAllows(IncomingMessage stage, string action)
        {
            return stage.PayloadAs<StagePayload>()
                .SupportedActions
                ?.Any(a => a.Action == action) == true;
        }

        // Subscribe to the card list for a ShowSelectCardView stage, and to every
        // later revision of it.
        //
        // MyID revises the list whenever readers come and go, reusing the same
        // eventId, so a picker that renders only the first revision goes stale the
        // moment a card is inserted or removed. The callback fires once per
        // revision - including immediately, if a revision has already arrived.
        //
        // Dispose the return value once the stage is answered.
        public IDisposable OnCardsChanged(IncomingMessage stage, Action<IReadOnlyList<CardInfo>> callback)
        {
            string eventId = RequireCardsEventId(stage);

            JsonElement cached = default;
            var haveCached = false;

            lock (eventLock)
            {
                haveCached = eventsById.TryGetValue(eventId, out cached);
            }

            if (haveCached)
            {
                callback(SelectableCards(cached));
            }

            return OnEvent(eventId, payload => callback(SelectableCards(payload)));
        }

        private static string RequireCardsEventId(IncomingMessage stage)
        {
            return stage.PayloadAs<StagePayload>().CardsChangedEventMessageId
                   ?? throw new MyIDException("The select-card stage did not name a card-list event.");
        }

        private static IReadOnlyList<CardInfo> SelectableCards(JsonElement payload)
        {
            if (payload.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null)
            {
                return [];
            }

            var cards = payload.Deserialize<CardsChangedPayload>(MyIDJson.Options);
            return cards?.Cards?.Where(c => c.ValidForSelection).ToList() ?? [];
        }

        //-----------------------------------------------------------------------------------------------------------
        // Logging and status.
        //-----------------------------------------------------------------------------------------------------------
        private void RaiseStatus(string text, StatusKind kind = StatusKind.Normal, IReadOnlyList<string>? detail = null)
        {
            Status?.Invoke(this, new StatusEventArgs(text, kind, detail ?? []));
        }

        // Mask secrets in a serialised envelope. Operating on the JSON rather than
        // the object means outgoing and incoming frames go through exactly the same
        // path, and an unknown payload shape is still covered.
        private static string Redact(string json)
        {
            try
            {
                JsonNode? node = JsonNode.Parse(json);
                RedactNode(node);
                return node?.ToJsonString(MyIDJson.Options) ?? json;
            }
            catch (JsonException)
            {
                // Never let the log break the workflow; if it won't parse, it was
                // not a payload we could have redacted anyway.
                return json;
            }
        }

        // Secrets can be nested, so walk the whole document rather than just the
        // top level of the payload.
        private static void RedactNode(JsonNode? node)
        {
            switch (node)
            {
                case JsonObject obj:
                    foreach (KeyValuePair<string, JsonNode?> property in obj.ToList())
                    {
                        if (SecretKeys.Contains(property.Key))
                        {
                            obj[property.Key] = "***";
                        }
                        else
                        {
                            RedactNode(property.Value);
                        }
                    }

                    break;

                case JsonArray array:
                    foreach (JsonNode? item in array)
                    {
                        RedactNode(item);
                    }

                    break;
            }
        }

        private sealed class Unsubscriber(Action dispose) : IDisposable
        {
            public void Dispose()
            {
                dispose();
            }
        }
    }

    public enum LogDirection
    {
        Sent,
        Received
    }

    public enum StatusKind
    {
        Normal,
        Error,
        Done
    }

    public sealed class LogEventArgs(LogDirection direction, string json) : EventArgs
    {
        public LogDirection Direction
        {
            get;
        } = direction;

        public string Json
        {
            get;
        } = json;
    }

    public sealed class StatusEventArgs(string text, StatusKind kind, IReadOnlyList<string> detail) : EventArgs
    {
        public string Text
        {
            get;
        } = text;

        public StatusKind Kind
        {
            get;
        } = kind;

        // The tertiary busy messages, if any.
        public IReadOnlyList<string> Detail
        {
            get;
        } = detail;
    }
}