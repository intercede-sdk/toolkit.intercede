//---------------------------------------------------------------------------------------------------------------
// Messages.cs
// ===========
//
// The wire types for the MyID WebSocket Client API.
//
// Every frame is a JSON "envelope": always an `action`, optionally a
// `routingId` (identifying the stage a message belongs to), and a `payload`.
// Incoming frames additionally carry a `type` that says how to
// interpret them. This sample does not leverage the correlationId functionality.
//
// The payload shape varies by message, so it is kept as a raw JsonElement and
// projected into a specific type only where a sample actually needs it. That
// keeps this file short, and means an unrecognised or extended payload never
// breaks deserialisation.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.Protocol
{
    using System.Text.Json;
    using System.Text.Json.Serialization;

    //---------------------------------------------------------------------------------------------------------------
// The `type` values the client sends us. Anything not listed here (for example
// AlertNotification) is ignored by these samples.
//---------------------------------------------------------------------------------------------------------------
    public static class MessageTypes
    {
        public const string ShowStage = "ShowStage";
        public const string EventNotification = "EventNotification";
        public const string BusyStateChanged = "BusyStateChangedNotification";
        public const string Error = "Error";
        public const string WorkflowControl = "WorkflowControl";
    }

//---------------------------------------------------------------------------------------------------------------
// Well-known action names.
//
// Note that the reply actions a stage will accept are ALWAYS the ones it
// advertises in supportedActions. Names like "Cancel" are reserved but are
// never guaranteed to be offered, so check with MyIDClient.StageAllows before
// sending one.
//---------------------------------------------------------------------------------------------------------------
    public static class Actions
    {
        // Initial actions that start a workflow.
        public const string WorkflowWithEmbeddedAuth = "WORKFLOWWITHEMBEDDEDAUTH";
        public const string WorkflowFromToken = "WORKFLOWFROMTOKEN";

        // Replies to a stage.
        public const string Continue = "Continue";
        public const string Cancel = "Cancel";

        // Stages this sample understands.
        public const string ShowSelectCardView = "ShowSelectCardView";
        public const string ShowCardPinLogonView = "ShowCardPinLogonView";
        public const string ShowNewPinView = "ShowNewPinView";
        public const string ShowSelectItemView = "ShowSelectItemView";
        public const string ShowErrorView = "ShowErrorView";

        // Notifications and control messages.
        public const string HideBusyMessage = "HideBusyMessage";
        public const string WorkflowComplete = "WorkflowComplete";
    }

//---------------------------------------------------------------------------------------------------------------
// An incoming frame, before the payload is interpreted.
//---------------------------------------------------------------------------------------------------------------
    public sealed class IncomingMessage
    {
        [JsonPropertyName("type")]
        public string? Type
        {
            get;
            set;
        }

        [JsonPropertyName("action")]
        public string? Action
        {
            get;
            set;
        }

        [JsonPropertyName("routingId")]
        public string? RoutingId
        {
            get;
            set;
        }

        // The card list arrives as a separate EventNotification, identified by this
        // rather than by routingId. See MyIDClient's event cache.
        [JsonPropertyName("eventId")]
        public string? EventId
        {
            get;
            set;
        }

        [JsonPropertyName("payload")]
        public JsonElement Payload
        {
            get;
            set;
        }

        // Project the raw payload into a specific shape.
        public T PayloadAs<T>() where T : new()
        {
            if (Payload.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null)
            {
                return new T();
            }

            return Payload.Deserialize<T>(MyIDJson.Options) ?? new T();
        }
    }

//---------------------------------------------------------------------------------------------------------------
// The payload of a stage that asks the user for something.
//
// One type covers every stage this sample handles: the fields are a union of
// what the individual stages send, and the ones that don't apply are simply
// absent. That is a simplification for readability - a production client would
// more likely model each stage separately.
//---------------------------------------------------------------------------------------------------------------
    public sealed class StagePayload
    {
        // The list properties below are nullable because the client sends optional
        // fields as an explicit null rather than omitting them. Read them with
        // `?? []`.

        // The only source of truth for which reply actions this stage will accept.
        [JsonPropertyName("supportedActions")]
        public List<SupportedAction>? SupportedActions
        {
            get;
            set;
        }

        // ShowSelectCardView: names the EventNotification carrying the card list.
        [JsonPropertyName("cardsChangedEventMessageId")]
        public string? CardsChangedEventMessageId
        {
            get;
            set;
        }

        // ShowNewPinView: the PIN rules, in human-readable form.
        [JsonPropertyName("pinPolicyItems")]
        public List<string>? PinPolicyItems
        {
            get;
            set;
        }

        // ShowSelectItemView: a generic "pick one of these" prompt.
        [JsonPropertyName("title")]
        public string? Title
        {
            get;
            set;
        }

        [JsonPropertyName("body")]
        public string? Body
        {
            get;
            set;
        }

        [JsonPropertyName("items")]
        public List<SelectableItem>? Items
        {
            get;
            set;
        }

        // ShowErrorView.
        [JsonPropertyName("errorMessage")]
        public string? ErrorMessage
        {
            get;
            set;
        }

        [JsonPropertyName("errorCode")]
        public string? ErrorCode
        {
            get;
            set;
        }
    }

//---------------------------------------------------------------------------------------------------------------
// An action a stage will accept. `action` is the stable key.
//---------------------------------------------------------------------------------------------------------------
    public sealed class SupportedAction
    {
        [JsonPropertyName("action")]
        public string? Action
        {
            get;
            set;
        }
    }

    public sealed class SelectableItem
    {
        [JsonPropertyName("id")]
        public string? Id
        {
            get;
            set;
        }

        [JsonPropertyName("text")]
        public string? Text
        {
            get;
            set;
        }
    }

//---------------------------------------------------------------------------------------------------------------
// The payload of a CardsChangedEvent.
//---------------------------------------------------------------------------------------------------------------
    public sealed class CardsChangedPayload
    {
        [JsonPropertyName("cards")]
        public List<CardInfo>? Cards
        {
            get;
            set;
        }
    }

    public sealed class CardInfo
    {
        [JsonPropertyName("serialNumber")]
        public string? SerialNumber
        {
            get;
            set;
        }

        [JsonPropertyName("deviceTypeName")]
        public string? DeviceTypeName
        {
            get;
            set;
        }

        [JsonPropertyName("deviceFriendlyName")]
        public string? DeviceFriendlyName
        {
            get;
            set;
        }

        [JsonPropertyName("cardholderName")]
        public string? CardholderName
        {
            get;
            set;
        }

        // Cards the workflow will not accept are still listed, flagged with false.
        // Absent means selectable, hence the default.
        [JsonPropertyName("validForSelection")]
        public bool ValidForSelection
        {
            get;
            set;
        } = true;

        // What the card picker shows for this card.
        public string DisplayName
        {
            get
            {
                string text = SerialNumber ?? "(unknown serial number)";

                if (!string.IsNullOrWhiteSpace(DeviceFriendlyName))
                {
                    text += $" ({DeviceFriendlyName})";
                }

                if (!string.IsNullOrWhiteSpace(CardholderName))
                {
                    text += $" - {CardholderName}";
                }

                return text;
            }
        }
    }

//---------------------------------------------------------------------------------------------------------------
// Progress reporting. HideBusyMessage carries no payload at all, so dispatch on
// the action rather than probing these fields.
//---------------------------------------------------------------------------------------------------------------
    public sealed class BusyPayload
    {
        [JsonPropertyName("primaryBusyMessage")]
        public string? PrimaryBusyMessage
        {
            get;
            set;
        }

        [JsonPropertyName("tertiaryBusyMessages")]
        public List<string>? TertiaryBusyMessages
        {
            get;
            set;
        }
    }

    public sealed class ErrorPayload
    {
        [JsonPropertyName("errorCode")]
        public string? ErrorCode
        {
            get;
            set;
        }

        [JsonPropertyName("errorMessage")]
        public string? ErrorMessage
        {
            get;
            set;
        }
    }

//---------------------------------------------------------------------------------------------------------------
// The outcome of the workflow, and the source of truth for whether it worked.
//
// A cancelled workflow reports Success: false with Aborted: true. That is a
// deliberate user choice rather than a failure, so callers should check Aborted
// before wording the outcome as an error.
//
// Both flags are nullable because the client sends these fields explicitly as
// null rather than omitting them - a successful workflow reports
// { "success": true, "aborted": null }. Treat a missing or null flag as false.
//---------------------------------------------------------------------------------------------------------------
    public sealed class WorkflowCompletePayload
    {
        [JsonPropertyName("success")]
        public bool? Success
        {
            get;
            set;
        }

        [JsonPropertyName("aborted")]
        public bool? Aborted
        {
            get;
            set;
        }

        [JsonPropertyName("errorMessage")]
        public string? ErrorMessage
        {
            get;
            set;
        }

        public bool IsSuccess
        {
            get
            {
                return Success == true;
            }
        }

        public bool IsAborted
        {
            get
            {
                return Aborted == true;
            }
        }
    }

//---------------------------------------------------------------------------------------------------------------
// What a stage handler returns: the action to reply with, and an optional
// payload. Returning null instead means "send nothing" - correct for stages
// that advance on their own.
//---------------------------------------------------------------------------------------------------------------
    public sealed record StageReply(string Action, object? Payload = null)
    {
        public static StageReply Continue(object? payload = null)
        {
            return new StageReply(Actions.Continue, payload);
        }

        public static StageReply Cancel()
        {
            return new StageReply(Actions.Cancel);
        }
    }

//---------------------------------------------------------------------------------------------------------------
// Anything that stops the workflow: an ApiError or ActionError, a ShowErrorView
// stage, an unsuccessful WorkflowComplete, or the connection closing early.
//
// The message names the MyID error code where there is one, so it can be shown
// to the user as-is.
//---------------------------------------------------------------------------------------------------------------
    public sealed class MyIDException(string message) : Exception(message);

    internal static class MyIDJson
    {
        // The client sends camelCase and tolerates it on the way back in.
        public static readonly JsonSerializerOptions Options = new()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
    }
}