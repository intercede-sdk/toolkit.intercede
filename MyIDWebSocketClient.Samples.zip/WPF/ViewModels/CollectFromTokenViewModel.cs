//---------------------------------------------------------------------------------------------------------------
// CollectFromTokenViewModel.cs
// ============================
//
// Collect a pending MyID job, started with WORKFLOWFROMTOKEN.
//
// The MyID operation extension token is supplied directly - paste it in. The extension token
// identifies the work to be done: it carries the metadata describing the
// operation and the job. There is no operation id here, and no user
// name: both come from the token.
//
// Acquiring an extension token yourself means talking to the MyID Core API, which is a
// separate concern and deliberately not part of this sample.
//
// The expected shape of the workflow is:
//
//     select card -> choose new PIN -> done
//
// with busy notifications in between, and possibly a ShowSelectItemView prompt.
// Any other stage is reported as an error rather than silently ignored.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels
{
    using CommunityToolkit.Mvvm.ComponentModel;
    using Protocol;

    public sealed partial class CollectFromTokenViewModel(Action goHome) : WorkflowViewModel(goHome)
    {
        // Optional: switch to this MyID server before starting.
        [ObservableProperty]
        private string serverAddress = string.Empty;

        [ObservableProperty]
        [NotifyCanExecuteChangedFor(nameof(StartCommand))]
        private string token = string.Empty;

        public override string Title
        {
            get
            {
                return "Collect a job using an extension token";
            }
        }

        public override string StartButtonText
        {
            get
            {
                return "Collect";
            }
        }

        protected override string SuccessMessage
        {
            get
            {
                return "Card collected successfully.";
            }
        }

        protected override string SelectCardPromptTitle
        {
            get
            {
                return "Select the card to collect to:";
            }
        }

        protected override bool CanStart()
        {
            return base.CanStart() && !string.IsNullOrWhiteSpace(Token);
        }

        protected override Task<WorkflowCompletePayload> RunWorkflowAsync(MyIDClient client, CancellationToken cancel)
        {
            var handlers = new Dictionary<string, Func<IncomingMessage, MyIDClient, Task<StageReply?>>>
            {
                [Actions.ShowSelectCardView] = OnSelectCardAsync,
                [Actions.ShowNewPinView] = OnNewPinAsync,
                [Actions.ShowSelectItemView] = OnSelectItemAsync
            };

            // serverAddress is omitted entirely when blank rather than sent empty,
            // so the client keeps whatever server it is already pointed at.
            object payload = string.IsNullOrWhiteSpace(ServerAddress)
                ? new { token = Token.Trim() }
                : new { token = Token.Trim(), serverAddress = ServerAddress.Trim() };

            return client.RunAsync(Actions.WorkflowFromToken, payload, handlers, cancel);
        }
    }
}