//---------------------------------------------------------------------------------------------------------------
// ChangePinViewModel.cs
// =====================
//
// Change My PIN: operation id 202, started with WORKFLOWWITHEMBEDDEDAUTH.
//
// "Embedded auth" means the client authenticates the named user itself, so no
// extension token is needed - just the user name. That is the difference between this and
// the collection sample, which is driven by an extension token instead.
//
// The expected shape of the workflow is:
//
//     select card -> enter current PIN -> choose new PIN -> done
//
// with busy notifications in between, and possibly a ShowSelectItemView prompt.
// Any other stage is reported as an error rather than silently ignored, so an
// unexpected credential-profile configuration names the stage that turned up.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels
{
    using CommunityToolkit.Mvvm.ComponentModel;
    using Prompts;
    using Protocol;

    public sealed partial class ChangePinViewModel(Action goHome) : WorkflowViewModel(goHome)
    {
        // Change My PIN.
        private const int OperationId = 202;

        [ObservableProperty]
        [NotifyCanExecuteChangedFor(nameof(StartCommand))]
        private string user = string.Empty;

        public override string Title
        {
            get
            {
                return "Change My PIN";
            }
        }

        public override string StartButtonText
        {
            get
            {
                return "Change PIN";
            }
        }

        protected override string SuccessMessage
        {
            get
            {
                return "PIN changed successfully.";
            }
        }

        protected override string SelectCardPromptTitle
        {
            get
            {
                return "Select the card to change the PIN on:";
            }
        }

        protected override bool CanStart()
        {
            return base.CanStart() && !string.IsNullOrWhiteSpace(User);
        }

        protected override Task<WorkflowCompletePayload> RunWorkflowAsync(MyIDClient client, CancellationToken cancel)
        {
            var handlers = new Dictionary<string, Func<IncomingMessage, MyIDClient, Task<StageReply?>>>
            {
                [Actions.ShowSelectCardView] = OnSelectCardAsync,
                [Actions.ShowCardPinLogonView] = OnCardPinLogonAsync,
                [Actions.ShowNewPinView] = OnNewPinAsync,
                [Actions.ShowSelectItemView] = OnSelectItemAsync
            };

            return client.RunAsync(
                Actions.WorkflowWithEmbeddedAuth,
                new { user = User.Trim(), operationid = OperationId },
                handlers,
                cancel);
        }

        // Authenticate to the card with the PIN it has today.
        private async Task<StageReply?> OnCardPinLogonAsync(IncomingMessage stage, MyIDClient client)
        {
            SetStatus("Waiting for you to enter your current PIN...");

            string? pin = await AskAsync(new PinPromptViewModel(
                "Enter your current PIN",
                null,
                MyIDClient.StageAllows(stage, Actions.Cancel)));

            if (pin is null)
            {
                return StageReply.Cancel();
            }

            SetStatus("Authenticating...");

            return StageReply.Continue(new { pin });
        }
    }
}