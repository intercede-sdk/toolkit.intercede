//---------------------------------------------------------------------------------------------------------------
// PinPromptViewModel.cs
// =====================
//
// Ask for the current PIN (ShowCardPinLogonView).
//
// The PIN itself is NOT an observable property: WPF's PasswordBox deliberately
// does not expose Password as a bindable DependencyProperty, so that a password
// is not left sitting in the binding system. The view pushes the value in from
// a small code-behind handler instead.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels.Prompts
{
    public sealed class PinPromptViewModel(string title, string? hint, bool allowCancel)
        : PromptViewModel<string?>(title, allowCancel)
    {
        public string? Hint
        {
            get;
        } = hint;

        // Set by the view as the user types.
        public string Pin
        {
            get;
            set;
        } = string.Empty;

        protected override void Submit()
        {
            if (string.IsNullOrEmpty(Pin))
            {
                ErrorMessage = "Enter your PIN.";
                return;
            }

            SetCompletionResult(Pin);
        }
    }
}