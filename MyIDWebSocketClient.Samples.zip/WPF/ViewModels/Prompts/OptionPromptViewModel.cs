//---------------------------------------------------------------------------------------------------------------
// OptionPromptViewModel.cs
// ========================
//
// A generic "pick one of these" prompt (ShowSelectItemView).
//
// MyID uses this for confirmations that aren't errors -- notably the warning
// raised when a device type isn't fully configured, which is normal on a test
// system but blocks the workflow until something is chosen.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels.Prompts
{
    using CommunityToolkit.Mvvm.ComponentModel;
    using Protocol;

    public sealed partial class OptionPromptViewModel : PromptViewModel<SelectableItem?>
    {
        [ObservableProperty]
        private SelectableItem? selectedItem;

        public OptionPromptViewModel(string? title, string? body, IReadOnlyList<SelectableItem> items, bool allowCancel)
            : base(string.IsNullOrWhiteSpace(title) ? "MyID is asking for a choice:" : title, allowCancel)
        {
            Body = body;
            Items = items;
            SelectedItem = items.FirstOrDefault();
        }

        public string? Body
        {
            get;
        }

        public bool HasBody
        {
            get
            {
                return !string.IsNullOrWhiteSpace(Body);
            }
        }

        public IReadOnlyList<SelectableItem> Items
        {
            get;
        }

        protected override void Submit()
        {
            if (SelectedItem is null)
            {
                ErrorMessage = "Select an option.";
                return;
            }

            SetCompletionResult(SelectedItem);
        }
    }
}