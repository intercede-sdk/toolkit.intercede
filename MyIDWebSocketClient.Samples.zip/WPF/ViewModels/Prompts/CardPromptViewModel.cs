//---------------------------------------------------------------------------------------------------------------
// CardPromptViewModel.cs
// ======================
//
// Pick a smartcard (ShowSelectCardView).
//
// The card list is LIVE. It does not arrive with the stage: MyID revises it
// whenever a reader or a card connects/disconnects, reusing the same event id.
//
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels.Prompts
{
    using System.Collections.ObjectModel;
    using CommunityToolkit.Mvvm.ComponentModel;
    using Protocol;

    public sealed partial class CardPromptViewModel(string title, bool allowCancel)
        : PromptViewModel<CardInfo?>(title, allowCancel)
    {
        [ObservableProperty]
        private CardInfo? selectedCard;

        private IDisposable? subscription;

        public ObservableCollection<CardInfo> Cards
        {
            get;
        } = [];

        // Shown instead of the list while no card is present.
        public bool IsWaitingForCard
        {
            get
            {
                return Cards.Count == 0;
            }
        }

        // Begin listening for card-list revisions. The callback fires once per
        // revision, including immediately if one has already arrived.
        public void Subscribe(MyIDClient client, IncomingMessage stage)
        {
            subscription = client.OnCardsChanged(stage, Refresh);
        }

        // Revisions arrive on the receive thread, so the collection update is
        // marshalled onto the UI thread.
        private void Refresh(IReadOnlyList<CardInfo> available)
        {
            Ui.Invoke(() =>
            {
                // Remember the choice by serial number so it can be restored even if
                // the card's position in the list has changed.
                string? previous = SelectedCard?.SerialNumber;

                Cards.Clear();

                foreach (CardInfo card in available)
                {
                    Cards.Add(card);
                }

                SelectedCard = Cards.FirstOrDefault(c => c.SerialNumber == previous) ?? Cards.FirstOrDefault();

                OnPropertyChanged(nameof(IsWaitingForCard));
            });
        }

        protected override void Submit()
        {
            if (SelectedCard is null)
            {
                ErrorMessage = "Select a card.";
                return;
            }

            SetCompletionResult(SelectedCard);
        }

        // Stop listening before settling either way, so a later revision cannot
        // redraw a prompt that has already been answered.
        public override void Unsubscribe()
        {
            subscription?.Dispose();
            subscription = null;
        }
    }
}