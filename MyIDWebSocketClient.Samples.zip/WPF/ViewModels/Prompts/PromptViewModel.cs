//---------------------------------------------------------------------------------------------------------------
// PromptViewModel.cs
// ==================
//
// The base for anything the workflow stops to ask the user.
//
// A stage handler needs to pause until the user answers. Each prompt therefore
// wraps a TaskCompletionSource: the handler awaits Completion, the view binds
// to the prompt through a DataTemplate, and Submit or Cancel settles it.
//
// A prompt can only be dismissed when the stage actually offers the Cancel
// action, which is why AllowCancel is passed in from the handler after checking
// supportedActions rather than being assumed.
//
// Cancelling a prompt means only "this prompt was dismissed" - NOT "the
// workflow is over". Replying Cancel ends the stage, and the server decides
// what comes next, which may well be more stages (cleaning up a partial change,
// say). WorkflowComplete remains the source of truth.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels.Prompts
{
    using CommunityToolkit.Mvvm.ComponentModel;
    using CommunityToolkit.Mvvm.Input;

    public abstract partial class PromptViewModel : ObservableObject
    {
        // Shown under the input when the user's entry is rejected locally, before
        // anything is sent to MyID.
        [ObservableProperty]
        private string? errorMessage;

        protected PromptViewModel(string title, bool allowCancel)
        {
            Title = title;
            AllowCancel = allowCancel;
        }

        public string Title
        {
            get;
        }

        // Whether the stage offered the Cancel action.
        public bool AllowCancel
        {
            get;
        }

        public abstract IRelayCommand SubmitCommand
        {
            get;
        }

        public abstract IRelayCommand CancelCommand
        {
            get;
        }
    }

//---------------------------------------------------------------------------------------------------------------
// A prompt that produces a TResult.
//
// Cancellation is represented by the result being default/null rather than by
// an exception: dismissing a prompt is an ordinary outcome the handler is
// expected to deal with, not an error.
//---------------------------------------------------------------------------------------------------------------
    public abstract class PromptViewModel<TResult> : PromptViewModel
    {
        private readonly TaskCompletionSource<TResult> completion =
            new(TaskCreationOptions.RunContinuationsAsynchronously);

        protected PromptViewModel(string title, bool allowCancel)
            : base(title, allowCancel)
        {
            // The delegates only capture `this`; Submit and CancelledResult are not
            // called until the user clicks, long after construction.
            SubmitCommand = new RelayCommand(Submit);
            CancelCommand = new RelayCommand(() => SetCompletionResult(CancelledResult), () => AllowCancel);
        }

        public Task<TResult> Completion
        {
            get
            {
                return completion.Task;
            }
        }

        public override IRelayCommand SubmitCommand
        {
            get;
        }

        public override IRelayCommand CancelCommand
        {
            get;
        }

        // What Completion yields when the prompt is dismissed.
        protected virtual TResult CancelledResult
        {
            get
            {
                return default!;
            }
        }

        // Validate and set result. Implementations set ErrorMessage and return
        // if the entry is not acceptable.
        protected abstract void Submit();

        protected void SetCompletionResult(TResult result)
        {
            completion.TrySetResult(result);
        }

        // Release anything the prompt subscribed to.
        public virtual void Unsubscribe() { }
    }
}