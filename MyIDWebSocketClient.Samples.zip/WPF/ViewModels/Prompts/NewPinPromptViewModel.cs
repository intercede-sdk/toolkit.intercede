//---------------------------------------------------------------------------------------------------------------
// NewPinPromptViewModel.cs
// ========================
//
// Choose a replacement PIN (ShowNewPinView).
//
// The stage tells us the PIN policy in human-readable form and we display it.
// A production client would ALSO send CheckPinPolicy to validate the PIN as the
// user types, before committing it; this sample only checks that the two
// entries match and lets an ActionError report anything MyID rejects.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels.Prompts
{
    public sealed class NewPinPromptViewModel(IReadOnlyList<string> pinPolicyItems, bool allowCancel)
        : PromptViewModel<string?>("Choose a new PIN for the card:", allowCancel)
    {
        public IReadOnlyList<string> PinPolicyItems
        {
            get;
        } = pinPolicyItems;

        public bool HasPinPolicy
        {
            get
            {
                return PinPolicyItems.Count > 0;
            }
        }

        // Both set by the view; see the note in PinPromptViewModel about PasswordBox.
        public string Pin
        {
            get;
            set;
        } = string.Empty;

        public string ConfirmPin
        {
            get;
            set;
        } = string.Empty;

        protected override void Submit()
        {
            if (string.IsNullOrEmpty(Pin))
            {
                ErrorMessage = "Enter a new PIN.";
                return;
            }

            if (Pin != ConfirmPin)
            {
                ErrorMessage = "The two PINs do not match.";
                return;
            }

            SetCompletionResult(Pin);
        }
    }
}