//---------------------------------------------------------------------------------------------------------------
// HomeViewModel.cs
// ================
//
// Pick an operation. Nothing more than two commands the shell supplies.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels
{
    using CommunityToolkit.Mvvm.ComponentModel;
    using CommunityToolkit.Mvvm.Input;

    public sealed class HomeViewModel : ObservableObject
    {
        public HomeViewModel(Action changePin, Action collect)
        {
            ChangePinCommand = new RelayCommand(changePin);
            CollectCommand = new RelayCommand(collect);
        }

        public IRelayCommand ChangePinCommand
        {
            get;
        }

        public IRelayCommand CollectCommand
        {
            get;
        }
    }
}