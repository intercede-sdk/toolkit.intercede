//---------------------------------------------------------------------------------------------------------------
// ShellViewModel.cs
// =================
//
// The navigation system, in its entirety.
//
// CurrentViewModel is bound to a ContentControl in MainWindow, and App.xaml
// maps each view-model type to a view with a DataTemplate. Swapping the
// property swaps the screen. There is no navigation framework and no DI
// container: the view models are simply constructed here.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels
{
    using CommunityToolkit.Mvvm.ComponentModel;

    public sealed partial class ShellViewModel : ObservableObject
    {
        private readonly HomeViewModel home;

        [ObservableProperty]
        private ObservableObject currentViewModel;

        public ShellViewModel()
        {
            home = new HomeViewModel(
                () => CurrentViewModel = new ChangePinViewModel(GoHome),
                () => CurrentViewModel = new CollectFromTokenViewModel(GoHome));

            currentViewModel = home;
        }

        // A workflow view model is discarded when it is left, so returning to it
        // later starts from a clean state rather than showing a stale log.
        private void GoHome()
        {
            CurrentViewModel = home;
        }
    }
}