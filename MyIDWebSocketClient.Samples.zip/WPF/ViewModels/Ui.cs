//---------------------------------------------------------------------------------------------------------------
// Ui.cs
// =====
//
// Marshal onto the WPF dispatcher.
//
// Stage handlers and status notifications run on the WebSocket receive thread,
// but bound properties and ObservableCollections may only be touched on the UI
// thread, so anything that updates view-model state goes through here.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels
{
    using System.Windows;
    using System.Windows.Threading;

    public static class Ui
    {
        public static void Invoke(Action action)
        {
            Dispatcher? dispatcher = Application.Current?.Dispatcher;

            if (dispatcher is null || dispatcher.CheckAccess())
            {
                action();
            }
            else
            {
                dispatcher.Invoke(action);
            }
        }
    }
}