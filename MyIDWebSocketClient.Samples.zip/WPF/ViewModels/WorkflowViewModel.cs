//---------------------------------------------------------------------------------------------------------------
// WorkflowViewModel.cs
// ====================
//
// The furniture every workflow in this sample needs: connection settings, the
// status line, the message log, and the currently displayed prompt.
//
// The important part is Prompt. A stage handler has to PAUSE while the user
// types a PIN or picks a card, so each prompt is a small view model exposing a
// Task that completes when the user answers. The handler awaits it, the UI
// binds to it through a DataTemplate, and the Submit/Cancel commands complete
// it. That keeps the handlers readable as straight-line async code.
//
// Everything that touches bound state marshals onto the dispatcher, because
// stage handlers and status notifications run on the WebSocket receive thread.
//---------------------------------------------------------------------------------------------------------------

namespace MyIDWebSocketClient.WpfSample.ViewModels
{
    using System.Collections.ObjectModel;
    using CommunityToolkit.Mvvm.ComponentModel;
    using CommunityToolkit.Mvvm.Input;
    using Prompts;
    using Protocol;

    public abstract partial class WorkflowViewModel : ObservableObject
    {
        private CancellationTokenSource? cancellation;

        [ObservableProperty]
        private string host = "localhost";

        [ObservableProperty]
        [NotifyCanExecuteChangedFor(nameof(StartCommand))]
        [NotifyCanExecuteChangedFor(nameof(GoHomeCommand))]
        private bool isRunning;

        [ObservableProperty]
        private int port = 1337;

        // Whatever the workflow is currently asking the user for, or null when it
        // is not waiting on anything. The view renders this with a DataTemplate.
        [ObservableProperty]
        private PromptViewModel? prompt;

        [ObservableProperty]
        private StatusKind statusKind = StatusKind.Normal;

        [ObservableProperty]
        private string statusText = "Idle.";

        protected WorkflowViewModel(Action goHome)
        {
            GoHomeCommand = new RelayCommand(goHome, () => !IsRunning);
        }

        // The tertiary busy messages that accompany the status line.
        public ObservableCollection<string> StatusDetail
        {
            get;
        } = [];

        public ObservableCollection<LogEntry> LogEntries
        {
            get;
        } = [];

        public IRelayCommand GoHomeCommand
        {
            get;
        }

        public abstract string Title
        {
            get;
        }

        // The text on the button that starts this workflow.
        public abstract string StartButtonText
        {
            get;
        }

        // What to say when the workflow completes successfully.
        protected abstract string SuccessMessage
        {
            get;
        }

        protected abstract string SelectCardPromptTitle
        {
            get;
        }

        [RelayCommand(CanExecute = nameof(CanStart))]
        private async Task StartAsync()
        {
            IsRunning = true;
            LogEntries.Clear();
            StatusDetail.Clear();
            Prompt = null;

            cancellation = new CancellationTokenSource();

            using var client = new MyIDClient { Host = Host, Port = Port };

            client.Log += OnLog;
            client.Status += OnStatus;

            try
            {
                await client.ConnectAsync(cancellation.Token);

                SetStatus("Starting the workflow...");
                WorkflowCompletePayload outcome = await RunWorkflowAsync(client, cancellation.Token);

                if (outcome.IsAborted)
                {
                    SetStatus(outcome.ErrorMessage ?? "The workflow was cancelled.");
                }
                else
                {
                    SetStatus(SuccessMessage, StatusKind.Done);
                }
            }
            catch (OperationCanceledException)
            {
                SetStatus("Cancelled.");
            }
            catch (Exception ex)
            {
                // ApiError, ActionError, ShowErrorView and unexpected stages all
                // land here with a message naming the MyID error code where there
                // is one.
                SetStatus(ex.Message, StatusKind.Error);
            }
            finally
            {
                client.Log -= OnLog;
                client.Status -= OnStatus;

                cancellation.Dispose();
                cancellation = null;

                Prompt = null;
                IsRunning = false;
            }
        }

        protected virtual bool CanStart()
        {
            return !IsRunning;
        }

        // Start the workflow and drive it to completion.
        protected abstract Task<WorkflowCompletePayload> RunWorkflowAsync(
            MyIDClient client,
            CancellationToken cancel);

        //-----------------------------------------------------------------------------------------------------------
        // Show a prompt and wait for the user to answer it.
        //
        // Called from a stage handler on the receive thread, so the prompt is
        // published on the dispatcher; the returned task completes when a command
        // on the prompt settles it.
        //-----------------------------------------------------------------------------------------------------------
        protected async Task<TResult> AskAsync<TResult>(PromptViewModel<TResult> prompt)
        {
            Ui.Invoke(() => Prompt = prompt);

            try
            {
                return await prompt.Completion;
            }
            finally
            {
                // Unsubscribe before clearing, so a late card-list revision cannot
                // redraw a prompt that has already been answered.
                prompt.Unsubscribe();

                Ui.Invoke(() =>
                {
                    if (ReferenceEquals(Prompt, prompt))
                    {
                        Prompt = null;
                    }
                });
            }
        }

        protected void SetStatus(string text, StatusKind kind = StatusKind.Normal, IReadOnlyList<string>? detail = null)
        {
            Ui.Invoke(() =>
            {
                StatusText = text;
                StatusKind = kind;

                StatusDetail.Clear();

                foreach (string line in detail ?? [])
                {
                    StatusDetail.Add(line);
                }
            });
        }

        //-----------------------------------------------------------------------------------------------------------
        // Stage handlers shared by both workflows.
        //
        // Selecting a card, choosing a new PIN and answering a selection prompt are
        // identical whether we are changing a PIN or collecting a job, so they live
        // here and each workflow composes them into its own handler map.
        //-----------------------------------------------------------------------------------------------------------

        // Pick a smartcard. The card list arrives as a separate CardsChangedEvent
        // and is revised as readers come and go, so the picker subscribes to it and
        // redraws itself rather than waiting for a card to be present up front.
        protected async Task<StageReply?> OnSelectCardAsync(IncomingMessage stage, MyIDClient client)
        {
            SetStatus("Waiting for you to select a card...");

            var prompt = new CardPromptViewModel(
                SelectCardPromptTitle,
                MyIDClient.StageAllows(stage, Actions.Cancel));

            prompt.Subscribe(client, stage);

            CardInfo? card = await AskAsync(prompt);

            if (card is null)
            {
                return StageReply.Cancel();
            }

            return StageReply.Continue(new
            {
                serialNumber = card.SerialNumber,
                deviceTypeName = card.DeviceTypeName
            });
        }

        // Choose the new PIN.
        protected async Task<StageReply?> OnNewPinAsync(IncomingMessage stage, MyIDClient client)
        {
            SetStatus("Waiting for you to choose a PIN...");

            var payload = stage.PayloadAs<StagePayload>();

            string? newPin = await AskAsync(new NewPinPromptViewModel(
                payload.PinPolicyItems ?? [],
                MyIDClient.StageAllows(stage, Actions.Cancel)));

            if (newPin is null)
            {
                return StageReply.Cancel();
            }

            SetStatus("Setting the new PIN...");

            return StageReply.Continue(new { newPin });
        }

        // A warning or confirmation that isn't an error, e.g. "this credential can
        // be issued, but the system is not fully configured for this type of
        // device". The workflow blocks until something is chosen.
        protected async Task<StageReply?> OnSelectItemAsync(IncomingMessage stage, MyIDClient client)
        {
            var payload = stage.PayloadAs<StagePayload>();
            List<SelectableItem> items = payload.Items ?? [];

            if (items.Count == 0)
            {
                throw new MyIDException("MyID asked for a selection but offered no options.");
            }

            SetStatus("Waiting for you to respond to a prompt...");

            SelectableItem? chosen = await AskAsync(new OptionPromptViewModel(
                payload.Title,
                payload.Body,
                items,
                MyIDClient.StageAllows(stage, Actions.Cancel)));

            if (chosen is null)
            {
                return StageReply.Cancel();
            }

            return StageReply.Continue(new { selectedOptionId = chosen.Id });
        }

        private void OnStatus(object? sender, StatusEventArgs e)
        {
            if (string.IsNullOrEmpty(e.Text))
            {
                Ui.Invoke(StatusDetail.Clear);
                return;
            }

            SetStatus(e.Text, e.Kind, e.Detail);
        }

        private void OnLog(object? sender, LogEventArgs e)
        {
            Ui.Invoke(() => LogEntries.Add(new LogEntry(e.Direction, e.Json)));
        }
    }

    public sealed record LogEntry(LogDirection Direction, string Json)
    {
        public string Arrow
        {
            get
            {
                return Direction == LogDirection.Sent ? "-->" : "<--";
            }
        }

        public string Text
        {
            get
            {
                return $"{Arrow} {Json}";
            }
        }
    }
}