namespace MyIDWebSocketClient.WpfSample.Views
{
    using System.Windows.Controls;

    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}