namespace MyIDWebSocketClient.WpfSample.Views
{
    using System.Windows.Controls;

    public partial class CollectFromTokenView : UserControl
    {
        public CollectFromTokenView()
        {
            InitializeComponent();
        }
    }
}