namespace MyIDWebSocketClient.WpfSample.Views
{
    using System.Globalization;
    using System.Windows;
    using System.Windows.Data;
    using System.Windows.Media;
    using Protocol;

    // Collapses an element when the bound bool is false.
    public sealed class BoolToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is true ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }

// Collapses an element when the bound value is null or an empty string.
    public sealed class NullToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is null || (value is string text && string.IsNullOrWhiteSpace(text))
                ? Visibility.Collapsed
                : Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }

// The status banner's colours, matching the HTML samples: blue for progress,
// red for an error, green for success.
//
// Pass ConverterParameter=Border in XAML for the stripe down the side, and
// leave it off for the background.
    public sealed class StatusKindToBrushConverter : IValueConverter
    {
        private static readonly SolidColorBrush ErrorBackground = Frozen("#FFEEEE");
        private static readonly SolidColorBrush ErrorBorder = Frozen("#CC3333");
        private static readonly SolidColorBrush DoneBackground = Frozen("#EEFFEE");
        private static readonly SolidColorBrush DoneBorder = Frozen("#33AA33");
        private static readonly SolidColorBrush NormalBackground = Frozen("#EEEEFF");
        private static readonly SolidColorBrush NormalBorder = Frozen("#6666AA");

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool border = parameter as string == "Border";

            return value switch
            {
                StatusKind.Error => border ? ErrorBorder : ErrorBackground,
                StatusKind.Done => border ? DoneBorder : DoneBackground,
                _ => border ? NormalBorder : NormalBackground
            };
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }

        // Brushes are created once and frozen: a converter runs on every value
        // change and should not be allocating.
        internal static SolidColorBrush Frozen(string colour)
        {
            var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colour)!);
            brush.Freeze();
            return brush;
        }
    }

// The message log's colours: sent one shade, received another.
    public sealed class LogDirectionToBrushConverter : IValueConverter
    {
        private static readonly SolidColorBrush Sent = StatusKindToBrushConverter.Frozen("#66CCFF");
        private static readonly SolidColorBrush Received = StatusKindToBrushConverter.Frozen("#99DD99");

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is LogDirection.Sent ? Sent : Received;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}