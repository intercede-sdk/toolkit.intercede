namespace MyIDWebSocketClient.WpfSample.Views.Prompts
{
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using ViewModels.Prompts;

    /// <summary>
    ///     See <see cref="PinPromptView" /> for why the PIN values are pushed across in
    ///     code rather than bound.
    /// </summary>
    public partial class NewPinPromptView : UserControl
    {
        public NewPinPromptView()
        {
            InitializeComponent();
            Loaded += (_, _) => PinBox.Focus();
        }

        private NewPinPromptViewModel? ViewModel
        {
            get
            {
                return DataContext as NewPinPromptViewModel;
            }
        }

        private void OnPinChanged(object sender, RoutedEventArgs e)
        {
            if (ViewModel is { } viewModel)
            {
                viewModel.Pin = PinBox.Password;
            }
        }

        private void OnConfirmChanged(object sender, RoutedEventArgs e)
        {
            if (ViewModel is { } viewModel)
            {
                viewModel.ConfirmPin = ConfirmBox.Password;
            }
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && ViewModel is { } viewModel)
            {
                viewModel.SubmitCommand.Execute(null);
            }
        }
    }
}