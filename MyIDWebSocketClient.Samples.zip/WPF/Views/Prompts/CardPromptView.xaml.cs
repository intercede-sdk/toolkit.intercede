namespace MyIDWebSocketClient.WpfSample.Views.Prompts
{
    using System.Windows.Controls;

    public partial class CardPromptView : UserControl
    {
        public CardPromptView()
        {
            InitializeComponent();
        }
    }
}