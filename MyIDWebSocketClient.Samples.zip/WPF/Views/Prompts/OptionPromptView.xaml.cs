namespace MyIDWebSocketClient.WpfSample.Views.Prompts
{
    using System.Windows.Controls;

    public partial class OptionPromptView : UserControl
    {
        public OptionPromptView()
        {
            InitializeComponent();
        }
    }
}