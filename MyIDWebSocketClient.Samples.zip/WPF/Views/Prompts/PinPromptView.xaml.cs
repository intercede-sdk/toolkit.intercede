namespace MyIDWebSocketClient.WpfSample.Views.Prompts
{
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using ViewModels.Prompts;

    /// <summary>
    ///     Code-behind exists here for one reason: <see cref="PasswordBox.Password" /> is
    ///     deliberately not a bindable dependency property, so that a password is not
    ///     left sitting in the binding system. Pushing the value across by hand is the
    ///     simplest way to respect that without pulling in a behaviours library.
    /// </summary>
    public partial class PinPromptView : UserControl
    {
        public PinPromptView()
        {
            InitializeComponent();
            Loaded += (_, _) => PinBox.Focus();
        }

        private void OnPasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is PinPromptViewModel viewModel)
            {
                viewModel.Pin = PinBox.Password;
            }
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && DataContext is PinPromptViewModel viewModel)
            {
                viewModel.SubmitCommand.Execute(null);
            }
        }
    }
}