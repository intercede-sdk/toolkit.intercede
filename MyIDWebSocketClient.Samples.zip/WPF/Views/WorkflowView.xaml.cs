namespace MyIDWebSocketClient.WpfSample.Views
{
    using System.Windows;
    using System.Windows.Controls;

    /// <summary>
    ///     The chrome shared by both workflow screens. The operation-specific settings
    ///     fields are supplied by the hosting view through <see cref="SettingsContent" />.
    /// </summary>
    public partial class WorkflowView : UserControl
    {
        public static readonly DependencyProperty SettingsContentProperty =
            DependencyProperty.Register(
                nameof(SettingsContent),
                typeof(object),
                typeof(WorkflowView),
                new PropertyMetadata(null));

        public WorkflowView()
        {
            InitializeComponent();
        }

        public object? SettingsContent
        {
            get
            {
                return GetValue(SettingsContentProperty);
            }

            set
            {
                SetValue(SettingsContentProperty, value);
            }
        }
    }
}