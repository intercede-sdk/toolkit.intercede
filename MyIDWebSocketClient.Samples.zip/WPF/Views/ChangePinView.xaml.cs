namespace MyIDWebSocketClient.WpfSample.Views
{
    using System.Windows.Controls;

    public partial class ChangePinView : UserControl
    {
        public ChangePinView()
        {
            InitializeComponent();
        }
    }
}