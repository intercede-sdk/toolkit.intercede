namespace MyIDWebSocketClient.WpfSample
{
    using System.Windows;
    using ViewModels;
    using Views;

    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // No DI container: the shell is the only thing that needs constructing,
            // and it builds the workflow view models itself.
            new MainWindow { DataContext = new ShellViewModel() }.Show();
        }
    }
}