#Requires -Version 7.0

<#
	CollectJobFromToken.Sample.ps1
	==============================

	An ULTRA-SIMPLIFIED example of collecting a pending MyID job from
	PowerShell, written to be read top-to-bottom as a tutorial.

	The MyID operation extension token is supplied directly, as a parameter. The extension token is what
	identifies the work to be done: it carries the metadata describing the
	operation and the job, which is why the WORKFLOWFROMTOKEN payload only needs
	{ token }.

	The WebSocket plumbing lives in lib/MyIDWebSocket.ps1 so both samples share
	it; read that file for the protocol details.

	This sample assumes a credential profile configured so that collection runs:

		busy -> select card -> busy -> set new PIN -> busy -> done

	Any other stage is reported as an error rather than silently ignored, so if
	your profile adds (say) security phrases you will be told exactly which
	stage turned up.

	This is deliberately NOT production code - see the header of
	lib/MyIDWebSocket.ps1 for the list of things it leaves out on purpose.

	Run it like:
		.\CollectJobFromToken.Sample.ps1 -Token '<extension-token>' -NewPin 123456 -Verbose

	Or, if more than one card is present:
		.\CollectJobFromToken.Sample.ps1 -Token '<extension-token>' -NewPin 123456 `
			-SerialNumber ABC123 -Verbose

	==========================================================

	AI Disclosure:
	    This sample was primarily generated using GitHub Copilot,
		which was provided with the MyID WebSocket Client API document
		as its primary source of reference.

	==========================================================
#>

[CmdletBinding()]
param(
	# The MyID operation extension token. Carries the operation and job metadata.
	[Parameter(Mandatory)] [string] $Token,

	# The PIN to set on the newly issued card.
	[Parameter(Mandatory)] [string] $NewPin,

	# Exact card serial number. Use an unknown value to list available cards.
	[Parameter(Mandatory)] [string] $SerialNumber,

	# Accept the first option in selection prompts. Off by default.
	[switch] $AcceptPrompts,

	# Switch to this MyID server before starting. Optional.
	[string] $ServerAddress,

	[string] $HostName       = 'localhost',
	[int]    $Port           = 1337,
	[string] $Origin         = 'http://localhost',
	[string] $ApiVersion     = '1.x',
	[int]    $TimeoutSeconds = 300
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Clear-Host

. (Join-Path $PSScriptRoot 'lib/MyIDWebSocket.ps1')

# Stage handlers reply to each ShowStage using its routingId.
$stageHandlers = @{

	# Cards arrive separately in CardsChangedEvent; the helper resolves the list.
	'ShowSelectCardView' = {
		param($stage)

		$card = Get-MyIDSelectableCard -Stage $stage -SerialNumber $SerialNumber
		Write-Verbose "Collecting onto card $($card.serialNumber)."

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{
			serialNumber   = $card.serialNumber
			deviceTypeName = $card.deviceTypeName
		}
	}

	# Choose the new PIN for the freshly issued card.
	#
	# This sample skips CheckPinPolicy and submits the PIN directly.
	'ShowNewPinView' = {
		param($stage)

		$payload = Get-MyIDPayload $stage
		if (Test-MyIDProperty $payload 'pinPolicyItems') {
			Write-Verbose "PIN policy: $($payload.pinPolicyItems -join '; ')"
		}

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{ newPin = $NewPin }
	}

	# Handle selection prompts, including non-error device configuration warnings.
	'ShowSelectItemView' = {
		param($stage)

		$payload = Get-MyIDPayload $stage
		$title   = if (Test-MyIDProperty $payload 'title') { $payload.title } else { '' }
		$body    = if (Test-MyIDProperty $payload 'body')  { $payload.body }  else { '' }
		$items   = if (Test-MyIDProperty $payload 'items') { @($payload.items) } else { @() }

		if ($items.Count -eq 0) {
			throw "MyID asked for a selection but offered no options. Title: '$title'. Body: '$body'"
		}

		Write-Host "MyID asks: $(($title, $body | Where-Object { $_ }) -join ' - ')" -ForegroundColor Yellow
		Write-Verbose "Options: $(($items | ForEach-Object { "$($_.id)=$($_.text)" }) -join ', ')"

		if (-not $AcceptPrompts) {
			throw "MyID is prompting for a choice: '$title $body'. Options: " +
				  "$(($items | ForEach-Object { $_.text }) -join ', '). " +
				  'Re-run with -AcceptPrompts to accept the first option automatically.'
		}

		$chosen = $items[0]
		Write-Host "Accepting: $($chosen.text)" -ForegroundColor Yellow

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{
			selectedOptionId = $chosen.id
		}
	}
}

# ---------------------------------------------------------------------------
# Run it.
# ---------------------------------------------------------------------------
try {
	Connect-MyIDClient -HostName $HostName -Port $Port -Origin $Origin `
		-ApiVersion $ApiVersion -TimeoutSeconds $TimeoutSeconds

	$payload = @{ token = $Token }
	if ($ServerAddress) { $payload.serverAddress = $ServerAddress }

	Write-Host 'Starting the collection...'
	$null = Invoke-MyIDWorkflow -InitialAction 'WORKFLOWFROMTOKEN' `
		-InitialPayload $payload -StageHandlers $stageHandlers

	Write-Host 'Card collected successfully.' -ForegroundColor Green
}
finally {
	Disconnect-MyIDClient
}
