#Requires -Version 7.0

<#
	ChangeMyPin.Sample.ps1
	======================

	An ULTRA-SIMPLIFIED example of changing the PIN on an existing MyID card
	from PowerShell, written to be read top-to-bottom as a tutorial.

	This is the non-interactive counterpart to ChangeMyPin.Sample.html: every
	value is supplied up front as a parameter, so the script can run unattended.

	Unlike the collection samples there is no extension token to obtain. Change My PIN is
	started with WORKFLOWWITHEMBEDDEDAUTH, naming the operation directly and
	letting the card itself authenticate the cardholder - which is why the
	current PIN is a parameter rather than something the Core API issues.

	The WebSocket plumbing lives in lib/MyIDWebSocket.ps1, shared with the other
	samples; read that file for the protocol details.

	This sample assumes the operation runs:

		busy -> select card -> card PIN logon -> set new PIN -> busy -> done

	Any other stage is reported as an error rather than silently ignored, so if
	your system adds a stage you will be told exactly which one turned up.

	This is deliberately NOT production code - see the header of
	lib/MyIDWebSocket.ps1 for the list of things it leaves out on purpose.

	Run it like:
		.\ChangeMyPin.Sample.ps1 -User jbloggs -SerialNumber ABC123 `
			-CurrentPin 123456 -NewPin 654321 -Verbose

	If you don't know the serial number, run with a placeholder: the error
	lists every card MyID offered.

	==========================================================

	AI Disclosure: 
	    This sample was primarily generated using GitHub Copilot, 
		which was provided with the MyID WebSocket Client API document 
		as its primary source of reference.

	==========================================================
#>

[CmdletBinding()]
param(
	# The MyID logon name of the cardholder whose PIN is being changed.
	[Parameter(Mandatory)] [string] $User,

	# Exact card serial number. Use an unknown value (e.g. '???') to list available cards.
	[Parameter(Mandatory)] [string] $SerialNumber,

	# The card's current PIN, used to authenticate the cardholder to the card.
	[Parameter(Mandatory)] [string] $CurrentPin,

	# New PIN; the policy is shown with -Verbose.
	[Parameter(Mandatory)] [string] $NewPin,

	# Accept the first option in selection prompts. Off by default.
	[switch] $AcceptPrompts,

	# Operation ID (202 is Change My PIN).
	[int] $OperationId = 202,

	# Switch to this MyID server before starting. Optional.
	[string] $ServerAddress,

	[string] $HostName       = 'localhost',
	[int]    $Port           = 1337,
	[string] $Origin         = 'http://localhost',
	[string] $ApiVersion     = '1.x',
	[int]    $TimeoutSeconds = 300
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Clear-Host

. (Join-Path $PSScriptRoot 'lib/MyIDWebSocket.ps1')

# Stage handlers reply to each ShowStage using its routingId.
$stageHandlers = @{

	# Cards arrive separately in CardsChangedEvent; the helper waits for the
	# requested card. Replies require both serialNumber and deviceTypeName.
	'ShowSelectCardView' = {
		param($stage)

		$card = Get-MyIDSelectableCard -Stage $stage -SerialNumber $SerialNumber
		Write-Verbose "Changing the PIN on card $($card.serialNumber)."

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{
			serialNumber   = $card.serialNumber
			deviceTypeName = $card.deviceTypeName
		}
	}

	# The card verifies this PIN for embedded authentication. ActionError is not
	# retried; repeated wrong PINs may lock the card.
	'ShowCardPinLogonView' = {
		param($stage)

		Write-Verbose 'Authenticating to the card with the current PIN.'
		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{ pin = $CurrentPin }
	}

	# Choose the new PIN.
	#
	# This sample skips CheckPinPolicy and submits the PIN directly.
	'ShowNewPinView' = {
		param($stage)

		$payload = Get-MyIDPayload $stage
		if (Test-MyIDProperty $payload 'pinPolicyItems') {
			Write-Verbose "PIN policy: $($payload.pinPolicyItems -join '; ')"
		}

		Write-Verbose 'Setting the new PIN.'
		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{ newPin = $NewPin }
	}

	# Handle selection prompts, including non-error device configuration warnings.
	'ShowSelectItemView' = {
		param($stage)

		$payload = Get-MyIDPayload $stage
		$title   = if (Test-MyIDProperty $payload 'title') { $payload.title } else { '' }
		$body    = if (Test-MyIDProperty $payload 'body')  { $payload.body }  else { '' }
		$items   = if (Test-MyIDProperty $payload 'items') { @($payload.items) } else { @() }

		if ($items.Count -eq 0) {
			throw "MyID asked for a selection but offered no options. Title: '$title'. Body: '$body'"
		}

		Write-Host "MyID asks: $(($title, $body | Where-Object { $_ }) -join ' - ')" -ForegroundColor Yellow
		Write-Verbose "Options: $(($items | ForEach-Object { "$($_.id)=$($_.text)" }) -join ', ')"

		if (-not $AcceptPrompts) {
			throw "MyID is prompting for a choice: '$title $body'. Options: " +
				  "$(($items | ForEach-Object { $_.text }) -join ', '). " +
				  'Re-run with -AcceptPrompts to accept the first option automatically.'
		}

		$chosen = $items[0]
		Write-Host "Accepting: $($chosen.text)" -ForegroundColor Yellow

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{
			selectedOptionId = $chosen.id
		}
	}
}

# WORKFLOWWITHEMBEDDEDAUTH names the user and operation directly; collection
# workflows use WORKFLOWFROMTOKEN when that metadata is in an extension token.
try {
	Connect-MyIDClient -HostName $HostName -Port $Port -Origin $Origin `
		-ApiVersion $ApiVersion -TimeoutSeconds $TimeoutSeconds

	$payload = @{
		user        = $User
		operationid = $OperationId
	}
	if ($ServerAddress) { $payload.serverAddress = $ServerAddress }

	Write-Host "Changing the PIN for $User..."
	$null = Invoke-MyIDWorkflow -InitialAction 'WORKFLOWWITHEMBEDDEDAUTH' `
		-InitialPayload $payload -StageHandlers $stageHandlers

	Write-Host 'PIN changed successfully.' -ForegroundColor Green
}
finally {
	Disconnect-MyIDClient
}
