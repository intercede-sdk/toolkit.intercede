#Requires -Version 7.0

<#
	MyIDWebSocket.ps1
	=================

	Shared WebSocket client used by the PowerShell samples.

	Dot-source it from a sample script:

		. (Join-Path $PSScriptRoot 'lib/MyIDWebSocket.ps1')

	This is deliberately NOT production code, with at least the following omissions:
	  * fragmented-frame reassembly (assumes each message arrives in one frame),
	  * SecureString handling (PINs are plain strings here),
	  * ActionError retry / interactive re-prompting,
	  * connection-state guards and fine-grained error mapping,
	  * the CheckPinPolicy round-trip before submitting a new PIN,
	  * the SaveErrorReport action offered by error stages.

	It DOES surface errors to the caller: a protocol-level ApiError (such as
	ClientNotAvailable or WorkflowAlreadyInProgress) and a workflow-level
	ShowErrorView are both turned into terminating errors rather than hanging
	the loop.

	==========================================================

	AI Disclosure: 
	    This sample was primarily generated using GitHub Copilot, 
		which was provided with the MyID WebSocket Client API document 
		as its primary source of reference.

	==========================================================
#>

using namespace System.Net.WebSockets

Set-StrictMode -Version Latest

# Connection state shared by the dot-sourced sample script.
$script:MyIDSocket         = $null
$script:MyIDTimeoutSeconds = 120

# ShowSelectCardView references a separate CardsChangedEvent by ID. Cache events
# because the stage and event can arrive in either order.
$script:MyIDEventsById = @{}

# How many lines the last busy message occupied, so the next one can paint over
# it. Zero means nothing is currently on screen.
$script:MyIDBusyLines = 0


function Connect-MyIDClient {
	<#
		.SYNOPSIS
			Connects to the MyID client.

		.DESCRIPTION
			Endpoint: ws[s]://<host>:<port>/v<version>/myidclient. The Origin must
			be allowed by the client's WS-AllowedOrigins setting.
	#>
	[CmdletBinding()]
	param(
		[string] $HostName       = 'localhost',
		[int]    $Port           = 1337,
		[string] $Origin         = 'http://localhost',
		[string] $ApiVersion     = '1.x',
		[switch] $UseTls,
		[int]    $TimeoutSeconds = 120
	)

	$scheme = if ($UseTls) { 'wss' } else { 'ws' }
	$uri    = "${scheme}://${HostName}:${Port}/v${ApiVersion}/myidclient"

	$socket = [ClientWebSocket]::new()
	$socket.Options.SetRequestHeader('Origin', $Origin)

	Write-Verbose "Connecting to $uri"
	try {
		# Wait synchronously; assign the void Task result to $null to suppress output.
		$null = $socket.ConnectAsync([uri] $uri, [System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
	}
	catch {
		throw "Could not connect to $uri. Check the MyID client is running, the port is correct, " +
			  "and that '$Origin' is listed in WS-AllowedOrigins. Underlying error: $($_.Exception.Message)"
	}

	$script:MyIDSocket         = $socket
	$script:MyIDTimeoutSeconds = $TimeoutSeconds
	$script:MyIDEventsById     = @{}
	$script:MyIDBusyLines      = 0
}


function Disconnect-MyIDClient {
	Clear-MyIDBusyLine

	if ($null -ne $script:MyIDSocket) {
		if ($script:MyIDSocket.State -eq [WebSocketState]::Open) {
			$null = $script:MyIDSocket.CloseAsync([WebSocketCloseStatus]::NormalClosure, 'Done',
				[System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
		}
		$script:MyIDSocket.Dispose()
		$script:MyIDSocket = $null
	}
}


# ---------------------------------------------------------------------------
# Mask secrets
# ---------------------------------------------------------------------------
function ConvertTo-MyIDRedactedJson {
	param([string] $Json)

	foreach ($key in @('pin', 'newPin', 'oldPin', 'token', 'client_secret', 'access_token')) {
		$Json = [regex]::Replace($Json, "(""$key""\s*:\s*)""[^""]*""", '$1"***"')
	}
	return $Json
}


function Send-MyIDMessage {
	<#
		.SYNOPSIS
			Sends a JSON message envelope.

		.DESCRIPTION
			Contains an action and may include a routingId and payload.
	#>
	param(
		[Parameter(Mandatory)] [string] $Action,
		[string]    $RoutingId,
		[hashtable] $Payload,
		[string]    $CorrelationId
	)

	$envelope = [ordered] @{ action = $Action }
	if ($RoutingId)     { $envelope.routingId     = $RoutingId }
	if ($CorrelationId) { $envelope.correlationId = $CorrelationId }
	if ($Payload)       { $envelope.payload       = $Payload }

	$json = $envelope | ConvertTo-Json -Depth 10 -Compress
	Write-Verbose "--> $(ConvertTo-MyIDRedactedJson $json)"

	$bytes   = [System.Text.Encoding]::UTF8.GetBytes($json)
	$segment = [ArraySegment[byte]]::new($bytes)
	$null = $script:MyIDSocket.SendAsync($segment, [WebSocketMessageType]::Text, $true,
		[System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
}


function Send-MyIDStageReply {
	<#
		.SYNOPSIS
			Replies to an open stage.

		.DESCRIPTION
			routingId is required on stage replies.
	#>
	param(
		[Parameter(Mandatory)] $Stage,
		[Parameter(Mandatory)] [string] $Action,
		[hashtable] $Payload
	)

	Send-MyIDMessage -Action $Action -RoutingId $Stage.routingId -Payload $Payload
}


function Receive-MyIDMessage {
	<#
		.SYNOPSIS
			Receives one envelope, or $null if the client closed the connection.

		.DESCRIPTION
			Assumes each message fits in one 16 KB frame.
	#>
	$buffer = [ArraySegment[byte]]::new([byte[]]::new(16384))
	$cts    = [System.Threading.CancellationTokenSource]::new([timespan]::FromSeconds($script:MyIDTimeoutSeconds))
	try {
		$result = $script:MyIDSocket.ReceiveAsync($buffer, $cts.Token).GetAwaiter().GetResult()
	}
	catch [System.OperationCanceledException] {
		throw "Timed out after $($script:MyIDTimeoutSeconds)s waiting for a message from the MyID client."
	}
	finally {
		$cts.Dispose()
	}

	if ($result.MessageType -eq [WebSocketMessageType]::Close) { return $null }

	$json = [System.Text.Encoding]::UTF8.GetString($buffer.Array, 0, $result.Count)
	Write-Verbose "<-- $(ConvertTo-MyIDRedactedJson $json)"
	return $json | ConvertFrom-Json
}


function Test-MyIDProperty {
	param($Object, [string] $Name)
	return ($null -ne $Object) -and ($Object.PSObject.Properties.Name -contains $Name)
}


function Get-MyIDPayload {
	<#
		.SYNOPSIS
			Returns a message payload, or $null when absent.

		.DESCRIPTION
			HideBusyMessage has no payload. Under StrictMode, check before reading
			optional properties.
	#>
	param($Message)

	if (Test-MyIDProperty $Message 'payload') { return $Message.payload }
	return $null
}


# Busy messages overwrite the previous status line. Verbose mode logs them
# instead. Long lines may wrap and leave a stray line behind.
function Clear-MyIDBusyLine {
	if ($VerbosePreference -ne 'SilentlyContinue') { return }
	if ($script:MyIDBusyLines -le 0) { return }

	# Move up one line and erase it.
	for ($i = 0; $i -lt $script:MyIDBusyLines; $i++) {
		[Console]::Write("`e[1A`e[2K")
	}
	$script:MyIDBusyLines = 0
}


function Write-MyIDBusyMessage {
	param($Payload)

	if ($VerbosePreference -ne 'SilentlyContinue') {
		if (Test-MyIDProperty $Payload 'primaryBusyMessage') {
			Write-Verbose "Busy: $($Payload.primaryBusyMessage)"
		}
		return
	}

	Clear-MyIDBusyLine

	$lines = @()
	if (Test-MyIDProperty $Payload 'primaryBusyMessage') {
		$lines += $Payload.primaryBusyMessage
	}

	# Display tertiary messages as indented sub-steps.
	if (Test-MyIDProperty $Payload 'tertiaryBusyMessages') {
		foreach ($tertiary in @($Payload.tertiaryBusyMessages)) {
			if (-not [string]::IsNullOrWhiteSpace($tertiary)) { $lines += "  $tertiary" }
		}
	}

	foreach ($line in $lines) { Write-Host $line }
	$script:MyIDBusyLines = $lines.Count
}


function Wait-MyIDEvent {
	<#
		.SYNOPSIS
			Waits for an event by ID, returning its payload or the cached payload.
	#>
	param([Parameter(Mandatory)] [string] $EventId)

	if ($script:MyIDEventsById.ContainsKey($EventId)) { return $script:MyIDEventsById[$EventId] }

	while ($true) {
		$msg = Receive-MyIDMessage
		if ($null -eq $msg) { throw 'The client closed the connection while waiting for an event.' }

		if ($msg.type -eq 'EventNotification' -and (Test-MyIDProperty $msg 'eventId')) {
			$payload = Get-MyIDPayload $msg
			$script:MyIDEventsById[$msg.eventId] = $payload
			if ($msg.eventId -eq $EventId) { return $payload }
		}
	}
}


function Get-MyIDSelectableCard {
	<#
		.SYNOPSIS
			Waits for the requested card in a ShowSelectCardView stage.

		.DESCRIPTION
			MyID reuses the eventId as the card list changes, so the requested card
			may appear in a later update. This sample requires a serial number rather
			than choosing a card silently.

		.PARAMETER SerialNumber
			Card serial number (matched case-insensitively).
	#>
	param(
		[Parameter(Mandatory)] $Stage,
		[Parameter(Mandatory)] [string] $SerialNumber,
		[int] $TimeoutSeconds = 60
	)

	$stagePayload = Get-MyIDPayload $Stage
	if (-not (Test-MyIDProperty $stagePayload 'cardsChangedEventMessageId')) {
		throw 'The select-card stage did not name a card-list event; cannot enumerate cards.'
	}

	$eventId  = $stagePayload.cardsChangedEventMessageId
	$wanted   = $SerialNumber.Trim()
	$deadline = [datetime]::UtcNow.AddSeconds($TimeoutSeconds)
	$payload  = Wait-MyIDEvent -EventId $eventId
	$seen     = @()

	while ($true) {
		# Exclude cards the workflow will not accept.
		$cards = @()
		if (Test-MyIDProperty $payload 'cards') {
			$cards = @($payload.cards | Where-Object {
				-not (Test-MyIDProperty $_ 'validForSelection') -or $_.validForSelection
			})
		}

		$seen = @($cards | ForEach-Object { $_.serialNumber })

		$card = $cards | Where-Object { $_.serialNumber -ieq $wanted } | Select-Object -First 1
		if ($null -ne $card) { return $card }

		if ([datetime]::UtcNow -ge $deadline) { break }

		Write-Verbose "Card '$wanted' not offered yet; waiting for the list to change. Currently: $($seen -join ', ')"

		# Wait for the next card-list revision.
		$updated = $false
		while (-not $updated) {
			if ([datetime]::UtcNow -ge $deadline) { break }

			$msg = Receive-MyIDMessage
			if ($null -eq $msg) { throw 'The client closed the connection while waiting for a card.' }

			if ($msg.type -eq 'EventNotification' -and (Test-MyIDProperty $msg 'eventId')) {
				$msgPayload = Get-MyIDPayload $msg
				$script:MyIDEventsById[$msg.eventId] = $msgPayload
				if ($msg.eventId -eq $eventId) {
					$payload = $msgPayload
					$updated = $true
				}
			}
		}

		if (-not $updated) { break }
	}

	if ($seen.Count -eq 0) {
		throw "No suitable smartcard was detected within ${TimeoutSeconds}s. Insert the card and try again."
	}

	throw "Card '$SerialNumber' was not offered within ${TimeoutSeconds}s. Available: $($seen -join ', ')"
}


function Invoke-MyIDWorkflow {
	<#
		.SYNOPSIS
			Starts an action and processes messages until the workflow ends.

		.DESCRIPTION
			Returns WorkflowComplete. Throws on MyID errors, unexpected stages, or
			an unexpected close.

		.PARAMETER StageHandlers
			Maps stage action names to scriptblocks. Each receives the stage message
			and replies with Send-MyIDStageReply, or returns nothing for auto-advance.
	#>
	[CmdletBinding()]
	param(
		[Parameter(Mandatory)] [string] $InitialAction,
		[hashtable] $InitialPayload,
		[Parameter(Mandatory)] [hashtable] $StageHandlers
	)

	Send-MyIDMessage -Action $InitialAction -Payload $InitialPayload -CorrelationId ([guid]::NewGuid().ToString())

	while ($true) {
		$message = Receive-MyIDMessage
		if ($null -eq $message) {
			Clear-MyIDBusyLine
			throw 'The client closed the connection before the workflow finished.'
		}

		$type    = if (Test-MyIDProperty $message 'type') { $message.type } else { $null }
		$payload = Get-MyIDPayload $message

		switch ($type) {

			'ShowStage' {
				# A stage means MyID is waiting for our reply.
				Clear-MyIDBusyLine

				# Surface workflow-level errors instead of stalling.
				if ($message.action -eq 'ShowErrorView') {
					$code = if (Test-MyIDProperty $payload 'errorCode')    { $payload.errorCode }    else { 'no code' }
					$text = if (Test-MyIDProperty $payload 'errorMessage') { $payload.errorMessage } else { 'The workflow reported an error.' }
					throw "MyID reported an error: $text ($code)"
				}

				$handler = $StageHandlers[$message.action]
				if ($null -eq $handler) {
					throw "Unexpected stage '$($message.action)'. This sample only handles: " +
						  "$(($StageHandlers.Keys | Sort-Object) -join ', '). " +
						  'Check the credential profile configuration.'
				}

				& $handler $message
			}

			'EventNotification' {
				if (Test-MyIDProperty $message 'eventId') {
					$script:MyIDEventsById[$message.eventId] = $payload
				}
			}

			'BusyStateChangedNotification' {
				# HideBusyMessage carries no payload at all.
				if ($message.action -eq 'HideBusyMessage') {
					Clear-MyIDBusyLine
				}
				else {
					Write-MyIDBusyMessage $payload
				}
			}

			'Error' {
				Clear-MyIDBusyLine

				# ActionError could be retried while the stage is open; these samples fail.
				$code = if (Test-MyIDProperty $payload 'errorCode') { $payload.errorCode } else { 'unknown error' }
				throw "$($message.action): $code"
			}

			'WorkflowControl' {
				if ($message.action -eq 'WorkflowComplete') {
					Clear-MyIDBusyLine

					if ((Test-MyIDProperty $payload 'success') -and $payload.success) {
						return $payload
					}

					$text = if (Test-MyIDProperty $payload 'errorMessage') { $payload.errorMessage } else { $null }
					throw "The workflow did not complete successfully. $text".Trim()
				}
			}

			default {
				# Ignore message types these samples do not use.
			}
		}
	}
}
