#Requires -Version 7.0

<#
	MyIDCoreApi.ps1
	===============

	OAuth and MyID Core API helpers shared by the PowerShell samples.

	Dot-source it from a sample script:

		. (Join-Path $PSScriptRoot 'lib/MyIDCoreApi.ps1')

	Covers three things:
	  1. Getting an access token (client credentials, or interactive PKCE).
	  2. The `operation` extension grant that mints a WORKFLOWFROMTOKEN token.
	  3. Just enough of the Core API to request a credential.

	The shapes used here were taken from a Fiddler capture of the MyID Operator
	Client performing a request-then-collect, so they reflect what the product
	itself sends rather than what seemed reasonable.

	This is deliberately NOT production code. It leaves out, on purpose:
	  * refresh tokens and expiry handling,
	  * paging over large result sets,
	  * retry / backoff,
	  * certificate pinning and proxy configuration.
#>

Set-StrictMode -Version Latest


function Get-MyIDClientCredentialsToken {
	<#
		.SYNOPSIS
			Gets an access token using the client_credentials grant.

		.DESCRIPTION
			The client is registered in web.oauth2's AppConfiguration.json with
			AllowedGrantTypes containing 'client_credentials' and a
			Properties.MyIDLogonName naming the MyID user it acts as - that is
			what makes this the "admin" identity.

			The secret is a GUID on the client side; the server stores
			base64(sha256(guid)).
	#>
	[CmdletBinding()]
	param(
		[Parameter(Mandatory)] [string] $TokenUrl,
		[Parameter(Mandatory)] [string] $ClientId,
		[Parameter(Mandatory)] [string] $ClientSecret,
		[string] $Scope = 'myid.rest.basic'
	)

	$body = @{
		grant_type    = 'client_credentials'
		client_id     = $ClientId
		client_secret = $ClientSecret
		scope         = $Scope
	}

	Write-Verbose "Requesting a client_credentials token from $TokenUrl as $ClientId."
	$response = Invoke-MyIDTokenRequest -TokenUrl $TokenUrl -Body $body
	return $response.access_token
}


function Get-MyIDInteractiveToken {
	<#
		.SYNOPSIS
			Gets an access token by signing a real person in through a browser,
			using the authorization code + PKCE flow.

		.DESCRIPTION
			Spins up a temporary loopback HTTP listener to catch the redirect,
			opens the system browser, and exchanges the returned code.

			`http://localhost:<port>/` must be registered as a redirect URI on
			the web.oauth2 client, and the client must allow the
			authorization_code grant with PKCE and no secret (a public client).

		.PARAMETER Prompt
			Passed through as the OAuth `prompt` parameter. Use 'login' to force
			a fresh sign-in - essential when signing in as two different people
			in one run, otherwise the auth server reuses the first session.
	#>
	[CmdletBinding()]
	param(
		[Parameter(Mandatory)] [string] $AuthorizeUrl,
		[Parameter(Mandatory)] [string] $TokenUrl,
		[Parameter(Mandatory)] [string] $ClientId,
		[string] $Scope          = 'myid.rest.basic',
		[int]    $RedirectPort   = 51789,
		[string] $Prompt         = 'login',
		[int]    $TimeoutSeconds = 300
	)

	$redirectUri = "http://localhost:$RedirectPort/"

	# PKCE (RFC 7636): the verifier stays here, only its SHA-256 hash travels
	# with the authorization request, so an intercepted code is useless alone.
	$verifierBytes = [byte[]]::new(32)
	[System.Security.Cryptography.RandomNumberGenerator]::Fill($verifierBytes)
	$codeVerifier = (ConvertTo-MyIDBase64Url $verifierBytes)

	$sha256 = [System.Security.Cryptography.SHA256]::Create()
	try {
		$challengeBytes = $sha256.ComputeHash([System.Text.Encoding]::ASCII.GetBytes($codeVerifier))
	}
	finally {
		$sha256.Dispose()
	}
	$codeChallenge = ConvertTo-MyIDBase64Url $challengeBytes

	$state = [guid]::NewGuid().ToString()

	$query = @(
		"response_type=code"
		"client_id=$([uri]::EscapeDataString($ClientId))"
		"scope=$([uri]::EscapeDataString($Scope))"
		"redirect_uri=$([uri]::EscapeDataString($redirectUri))"
		"state=$([uri]::EscapeDataString($state))"
		"code_challenge_method=S256"
		"code_challenge=$([uri]::EscapeDataString($codeChallenge))"
	)
	if ($Prompt) { $query += "prompt=$([uri]::EscapeDataString($Prompt))" }

	$separator = if ($AuthorizeUrl.Contains('?')) { '&' } else { '?' }
	$url = $AuthorizeUrl + $separator + ($query -join '&')

	$listener = [System.Net.HttpListener]::new()
	$listener.Prefixes.Add($redirectUri)

	try {
		$listener.Start()
	}
	catch {
		throw "Could not listen on $redirectUri. Either the port is in use, or this shell " +
			  "lacks permission to reserve it. Underlying error: $($_.Exception.Message)"
	}

	try {
		Write-Host "Opening a browser to sign in$(if ($Prompt -eq 'login') { ' (you will be asked to sign in even if already signed in)' })..."
		Start-Process $url | Out-Null

		# ❗ The first request to hit the listener is not necessarily the
		# redirect. Browsers speculatively fetch /favicon.ico for the page we
		# served on a previous sign-in, and that request carries neither
		# `code` nor `error`. Keep answering until the real one arrives, but
		# don't block forever if the user walks away.
		$deadline    = [datetime]::UtcNow.AddSeconds($TimeoutSeconds)
		$queryString = $null

		while ($true) {
			$remaining = $deadline - [datetime]::UtcNow
			if ($remaining -le [timespan]::Zero) {
				throw "Timed out after ${TimeoutSeconds}s waiting for the browser sign-in to complete."
			}

			$contextTask = $listener.GetContextAsync()
			if (-not $contextTask.Wait($remaining)) {
				throw "Timed out after ${TimeoutSeconds}s waiting for the browser sign-in to complete."
			}

			$context = $contextTask.Result
			$request = $context.Request
			$isRedirect = $null -ne $request.QueryString['code'] -or $null -ne $request.QueryString['error']

			if (-not $isRedirect) {
				# Something incidental, e.g. /favicon.ico. Dismiss it quietly
				# and keep waiting for the redirect.
				Write-Verbose "Ignoring an unrelated request to $($request.Url.AbsolutePath) while waiting for the redirect."
				$context.Response.StatusCode = 404
				$context.Response.Close()
				continue
			}

			$queryString = $request.QueryString

			# Always answer the browser, so the user isn't left on a hung tab.
			$message = if ($queryString['code']) { 'Signed in. You can close this tab and return to PowerShell.' }
					   else { "Sign-in failed: $($queryString['error']). You can close this tab." }
			$bytes = [System.Text.Encoding]::UTF8.GetBytes("<html><head><link rel='icon' href='data:,'></head><body style='font-family:sans-serif'>$message</body></html>")
			$context.Response.ContentType = 'text/html'
			$context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
			$context.Response.Close()
			break
		}

		if (-not $queryString['code']) {
			throw "Sign-in failed: $($queryString['error'] ?? 'no authorization code was returned')."
		}
		if ($queryString['state'] -ne $state) {
			throw 'Invalid state returned from the auth server; aborting.'
		}

		$body = @{
			grant_type    = 'authorization_code'
			code          = $queryString['code']
			redirect_uri  = $redirectUri
			client_id     = $ClientId
			code_verifier = $codeVerifier
		}

		$response = Invoke-MyIDTokenRequest -TokenUrl $TokenUrl -Body $body
		return $response.access_token
	}
	finally {
		$listener.Stop()
		$listener.Close()
	}
}


function Get-MyIDOperationToken {
	<#
		.SYNOPSIS
			Mints the token consumed by WORKFLOWFROMTOKEN, using the MyID
			`operation` extension grant.

		.DESCRIPTION
			The token carries the metadata describing what to run - the
			operation and the request - which is why the WORKFLOWFROMTOKEN
			payload only needs { token }.

			We do not build the request body. MyID hands us the whole thing,
			ready-made, in the `auth` field of a link (see
			Get-MyIDCollectionAuthTemplate). It looks like this, with a literal
			`{token}` placeholder that we substitute:

				client_id=myid.mcs&grant_type=operation&op=216
				&scope=myid.operation&requestId=<guid>&token={token}

			That matters because `op` identifies the MyID operation and varies
			by deployment and by credential profile - it cannot be hard-coded.
			Posting the server's own string back verbatim means there are no
			field names in this script to get wrong.

			The minted token is short-lived (the `myid.mcs` client's
			OperationTokenLifetime, 300 seconds on a default install), so mint
			it immediately before collecting rather than caching it.

		.PARAMETER AuthTemplate
			The `auth` string from the collection link, containing `{token}`.

		.PARAMETER AccessToken
			The cardholder's access token, substituted into the template. Note
			it travels in the form body, not in an Authorization header.
	#>
	[CmdletBinding()]
	param(
		[Parameter(Mandatory)] [string] $TokenUrl,
		[Parameter(Mandatory)] [string] $AuthTemplate,
		[Parameter(Mandatory)] [string] $AccessToken
	)

	if ($AuthTemplate -notmatch '\{token\}') {
		throw "The collection link's auth string does not contain a {token} placeholder, so there is " +
			  "nowhere to put the cardholder's token. Received: $AuthTemplate"
	}

	# The template is already form-encoded, so send it as a pre-built string
	# rather than a hashtable - PowerShell would otherwise re-encode it.
	$body = $AuthTemplate.Replace('{token}', [uri]::EscapeDataString($AccessToken))

	Write-Verbose "Requesting an 'operation' grant token from $TokenUrl."
	$response = Invoke-MyIDTokenRequest -TokenUrl $TokenUrl -Body $body -GrantDescription 'operation'
	return $response.access_token
}


function Get-MyIDCollectionAuthTemplate {
	<#
		.SYNOPSIS
			Finds the collection link MyID offers for a request, and returns the
			ready-made `operation` grant body from it.

		.DESCRIPTION
			MyID advertises the actions available on an entity as a `links`
			array. Actions needing an operation token carry `cat: "myid.mcs"`
			and an `auth` field holding the entire grant body, with a literal
			`{token}` placeholder:

				{ "op": "216", "cat": "myid.mcs", "desc": "Collect: Auto PIV Soak",
				  "entity": "requests",
				  "auth": "client_id=myid.mcs&grant_type=operation&op=216
						   &scope=myid.operation&requestId=<guid>&token={token}" }

			We look in the cardholder's own session first, because that is what
			the Operator Client does and because the link is then guaranteed to
			describe something *this* user may collect. `sessions/self` only
			offers it once the cardholder has signed in and has a collectable
			request waiting.

			The request itself also carries a collection link, but it is the
			administrator's view of the same action and its `op` differs, so it
			is only a fallback.

		.PARAMETER AccessToken
			The cardholder's access token - not the administrator's.

		.PARAMETER RequestId
			The request `id` GUID. Used to pick the right link when several are
			offered, and for the fallback lookup.

		.OUTPUTS
			An object with `auth` (the template) and `desc` (a human-readable
			description, e.g. "Collect: Auto PIV Soak").
	#>
	[CmdletBinding()]
	param(
		[Parameter(Mandatory)] [string] $ApiUrl,
		[Parameter(Mandatory)] [string] $AccessToken,
		[Parameter(Mandatory)] [string] $RequestId
	)

	# 1. The cardholder's own session.
	$session = Invoke-MyIDCoreApi -ApiUrl $ApiUrl -AccessToken $AccessToken -Path 'sessions/self'
	$link    = Select-MyIDCollectionLink -Links $session.links -RequestId $RequestId

	# 2. Fall back to the request's own links.
	if (-not $link) {
		Write-Verbose "No collection link in sessions/self; trying requests/$RequestId."
		try {
			$request = Invoke-MyIDCoreApi -ApiUrl $ApiUrl -AccessToken $AccessToken `
				-Path "requests/$RequestId"
			$link = Select-MyIDCollectionLink -Links $request.links -RequestId $RequestId
		}
		catch {
			Write-Verbose "Could not read requests/${RequestId}: $($_.Exception.Message)"
		}
	}

	if (-not $link) {
		throw "MyID did not offer a collection link for request $RequestId, in either " +
			  "'sessions/self' or 'requests/$RequestId'. The usual causes are that the signed-in " +
			  "user is not the person the credential was requested for, that the request is no " +
			  "longer 'Awaiting Issue', or that its credential profile does not permit collection " +
			  "by this user."
	}

	if (-not (Test-MyIDCoreProperty $link 'auth')) {
		throw "The collection link for request $RequestId has no 'auth' field, so there is no " +
			  "grant body to send. Link: $($link | ConvertTo-Json -Compress -Depth 5)"
	}

	Write-Verbose "Using collection link '$($link.desc)' (op $($link.op))."

	return [pscustomobject]@{
		auth = $link.auth
		desc = if (Test-MyIDCoreProperty $link 'desc') { $link.desc } else { 'Collect' }
	}
}


function Select-MyIDCollectionLink {
	<#
		.SYNOPSIS
			Picks the operation-token link out of a `links` array, preferring one
			that names the request we care about.
	#>
	param($Links, [string] $RequestId)

	if (-not $Links) { return $null }

	$candidates = @($Links | Where-Object {
		$_ -and (Test-MyIDCoreProperty $_ 'cat') -and $_.cat -eq 'myid.mcs'
	})

	if ($candidates.Count -eq 0) { return $null }

	# A session may offer collection links for several pending requests.
	$forThisRequest = @($candidates | Where-Object {
		(Test-MyIDCoreProperty $_ 'auth') -and $_.auth -match [regex]::Escape($RequestId)
	})

	if ($forThisRequest.Count -gt 0) { return $forThisRequest[0] }

	return $candidates[0]
}


function Test-MyIDCoreProperty {
	<#
		.SYNOPSIS
			Safe property test, needed because Set-StrictMode makes touching a
			missing property on a PSCustomObject a terminating error.
	#>
	param($Object, [string] $Name)

	if ($null -eq $Object) { return $false }
	return [bool]($Object.PSObject.Properties.Name -contains $Name)
}


function Test-MyIDCoreFlag {
	<#
		.SYNOPSIS
			Tests a boolean-ish Core API property.

		.DESCRIPTION
			The Core API renders some booleans as the strings "Yes"/"No" or
			"True"/"False" rather than as JSON booleans. PowerShell treats
			every non-empty string as $true, so "No" would otherwise pass a
			plain truthiness test.
	#>
	param($Object, [string] $Name)

	if (-not (Test-MyIDCoreProperty $Object $Name)) { return $false }

	$value = $Object.$Name
	if ($null -eq $value)      { return $false }
	if ($value -is [bool])     { return $value }
	if ($value -is [string])   { return $value -in @('Yes', 'True', '1') }
	return [bool]$value
}


function Invoke-MyIDTokenRequest {
	<#
		.SYNOPSIS
			POSTs a form-encoded token request and returns the parsed response,
			turning OAuth error responses into readable terminating errors.
	#>
	param(
		[Parameter(Mandatory)] [string] $TokenUrl,
		[Parameter(Mandatory)] $Body,
		[string] $GrantDescription
	)

	try {
		return Invoke-RestMethod -Method Post -Uri $TokenUrl -Body $Body `
			-ContentType 'application/x-www-form-urlencoded'
	}
	catch {
		# The OAuth error detail lives in the response body, not the status line.
		$detail = $null
		if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
			try {
				$parsed = $_.ErrorDetails.Message | ConvertFrom-Json
				$detail = @($parsed.error, $parsed.error_description | Where-Object { $_ }) -join ': '
			}
			catch {
				$detail = $_.ErrorDetails.Message
			}
		}

		$grant = if ($GrantDescription) { $GrantDescription }
				 elseif ($Body -is [hashtable]) { $Body['grant_type'] }
				 else { 'token' }
		throw "The '$grant' token request to $TokenUrl failed. $($detail ?? $_.Exception.Message)"
	}
}


function ConvertTo-MyIDBase64Url {
	param([byte[]] $Bytes)
	return [Convert]::ToBase64String($Bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_')
}


# ---------------------------------------------------------------------------
# Core API
#
# Search responses are wrapped as { results: [ ... ] }; errors carry `message`
# and `code`.
# ---------------------------------------------------------------------------

function Invoke-MyIDCoreApi {
	param(
		[Parameter(Mandatory)] [string] $ApiUrl,
		[Parameter(Mandatory)] [string] $Path,
		[Parameter(Mandatory)] [string] $AccessToken,
		[string] $Method = 'Get',
		$Body
	)

	$uri = ($ApiUrl.TrimEnd('/')) + '/' + $Path.TrimStart('/')
	Write-Verbose "$Method $uri"

	$params = @{
		Method  = $Method
		Uri     = $uri
		Headers = @{ Authorization = "Bearer $AccessToken" }
	}
	if ($null -ne $Body) {
		$params.Body        = ($Body | ConvertTo-Json -Depth 10)
		$params.ContentType = 'application/json'
	}

	return Invoke-RestMethod @params
}


function Get-MyIDExactlyOneResult {
	param($Response, [string] $What)

	$results = @()
	if (Test-MyIDCoreProperty $Response 'results') {
		$results = @($Response.results)
	}

	if ($results.Count -eq 0) { throw "No $What found." }
	if ($results.Count -gt 1) { throw "More than one $What matched; be more specific." }
	return $results[0]
}


function Get-MyIDCredentialProfile {
	<#
		.SYNOPSIS
			Finds a credential profile by name.

		.DESCRIPTION
			The `credentialProfiles` endpoint returns every version of a
			profile, so we filter to the latest. On MyID 12.16 and earlier that
			endpoint doesn't exist, and we fall back to the older
			`credprofiles` one.
	#>
	param(
		[Parameter(Mandatory)] [string] $ApiUrl,
		[Parameter(Mandatory)] [string] $AccessToken,
		[Parameter(Mandatory)] [string] $Name
	)

	$encoded = [uri]::EscapeDataString($Name)

	try {
		$response = Invoke-MyIDCoreApi -ApiUrl $ApiUrl -AccessToken $AccessToken `
			-Path "credentialProfiles?name=$encoded&f=false"

		$candidates = @()
		if (Test-MyIDCoreProperty $response 'results') { $candidates = @($response.results) }

		# ❗ `latestVersion` comes back as the string "Yes"/"No", not a boolean.
		# A plain truthiness test would keep both, because every non-empty
		# string is truthy in PowerShell.
		$latest = @($candidates | Where-Object { Test-MyIDCoreFlag $_ 'latestVersion' })
		if ($latest.Count -eq 0 -and $candidates.Count -eq 1) { return $candidates[0] }

		# `name=` is a partial match, so "Auto PIV Soak" also returns
		# "Auto PIV Soak Test". Narrow to an exact name before giving up.
		if ($latest.Count -gt 1) {
			$exact = @($latest | Where-Object { (Test-MyIDCoreProperty $_ 'name') -and $_.name -eq $Name })
			if ($exact.Count -eq 1) { return $exact[0] }
		}

		if ($latest.Count -eq 1) { return $latest[0] }
		if ($latest.Count -gt 1) {
			$names = ($latest | ForEach-Object {
				if (Test-MyIDCoreProperty $_ 'name') { $_.name } else { '<unnamed>' }
			}) -join ', '
			throw "More than one credential profile matched '$Name': $names. Use the exact profile name."
		}
	}
	catch {
		# Only a 404 means "this endpoint doesn't exist here". Anything else --
		# including an error we raised ourselves above -- must surface. Read the
		# status defensively: not every exception carries a Response, and under
		# StrictMode a blind property access would mask the real failure.
		$status = $null
		$ex     = $_.Exception
		if ($null -ne $ex -and (Test-MyIDCoreProperty $ex 'Response') -and $null -ne $ex.Response) {
			if (Test-MyIDCoreProperty $ex.Response 'StatusCode') { $status = $ex.Response.StatusCode }
		}

		if ($status -ne [System.Net.HttpStatusCode]::NotFound) { throw }
		Write-Verbose "The 'credentialProfiles' endpoint was not found; this MyID system may be 12.16 or earlier. Trying 'credprofiles'."
	}

	$legacy = Invoke-MyIDCoreApi -ApiUrl $ApiUrl -AccessToken $AccessToken `
		-Path "credprofiles?q=$encoded&f=false"
	return Get-MyIDExactlyOneResult -Response $legacy -What "credential profile named '$Name'"
}


function New-MyIDCredentialRequest {
	<#
		.SYNOPSIS
			Requests a credential for a user, returning the whole request object.

		.DESCRIPTION
			Tries the database user search first and falls back to searching
			every directory, matching the behaviour of the HeadlessMyIDClient
			AutomatorRestClient. MyID PRO, and any deployment with database user
			searching disabled, needs the directory path.

			❗ The response carries two different identifiers, and they are easy
			to confuse:

				"id":    "83A6FB60-E6E3-48FB-8A7E-1CE02E9F9D89"   <- the request
				"jobId": "16"                                    <- the job

			The `operation` grant keys off `id`, the GUID. `jobId` is the short
			numeric job reference shown in the MyID UI and is not what the grant
			wants.
	#>
	param(
		[Parameter(Mandatory)] [string] $ApiUrl,
		[Parameter(Mandatory)] [string] $AccessToken,
		[Parameter(Mandatory)] [string] $LogonName,
		[Parameter(Mandatory)] $CredentialProfile
	)

	$encoded = [uri]::EscapeDataString($LogonName)
	$body    = @{ credProfile = @{ id = $CredentialProfile.id } }

	# 1. Database user.
	try {
		$response = Invoke-MyIDCoreApi -ApiUrl $ApiUrl -AccessToken $AccessToken `
			-Path "people?f=false&logonName=$encoded"
		$user = Get-MyIDExactlyOneResult -Response $response -What "user named '$LogonName'"

		Write-Verbose "Requesting $($CredentialProfile.name) for database user $LogonName."
		return Invoke-MyIDCoreApi -ApiUrl $ApiUrl -AccessToken $AccessToken `
			-Path "people/$($user.id)/requests" -Method Post -Body $body
	}
	catch {
		# `DatabaseUserSearchDisabled` means we must search directories instead.
		$isDisabled = $_.ErrorDetails -and $_.ErrorDetails.Message -match 'DatabaseUserSearchDisabled'
		if (-not $isDisabled) { throw }
		Write-Verbose 'Database user searching is disabled. Searching directories instead.'
	}

	# 2. Directory user. We don't know which directory, so try each in turn.
	$directories = Invoke-MyIDCoreApi -ApiUrl $ApiUrl -AccessToken $AccessToken -Path 'dirs/'

	foreach ($directory in $directories.results) {
		try {
			$response = Invoke-MyIDCoreApi -ApiUrl $ApiUrl -AccessToken $AccessToken `
				-Path "dirs/$($directory.id)/people?ldap.logonName=$encoded"
			$user = Get-MyIDExactlyOneResult -Response $response -What "user named '$LogonName'"
		}
		catch {
			Write-Verbose "Could not find $LogonName in $($directory.name)."
			continue
		}

		Write-Verbose "Requesting $($CredentialProfile.name) for directory user $LogonName in $($directory.name)."
		return Invoke-MyIDCoreApi -ApiUrl $ApiUrl -AccessToken $AccessToken `
			-Path "dirs/$($directory.id)/people/$($user.id)/requests" -Method Post -Body $body
	}

	throw "Could not find a user named '$LogonName' in the database or in any directory."
}
