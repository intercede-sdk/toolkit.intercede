#Requires -Version 7.0

<#
	MyIDWebSocket.ps1
	=================

	Shared WebSocket plumbing for the MyID WebSocket Client API samples.

	Dot-source it from a sample script:

		. (Join-Path $PSScriptRoot 'lib/MyIDWebSocket.ps1')

	This is deliberately NOT production code. Compared to the real
	HeadlessClientConsumer.psm1 module it leaves out, on purpose:
	  * fragmented-frame reassembly (assumes each message arrives in one frame),
	  * SecureString handling (PINs are plain strings here),
	  * ActionError retry / interactive re-prompting,
	  * connection-state guards and fine-grained error mapping,
	  * the CheckPinPolicy round-trip before submitting a new PIN,
	  * the SaveErrorReport action offered by error stages.

	It DOES surface errors to the caller: a protocol-level ApiError (such as
	ClientNotAvailable or WorkflowAlreadyInProgress) and a workflow-level
	ShowErrorView are both turned into terminating errors rather than hanging
	the loop.
#>

using namespace System.Net.WebSockets

Set-StrictMode -Version Latest

# ---------------------------------------------------------------------------
# Connection state.
#
# Kept in script scope so the sample scripts read like the tutorial they are,
# rather than threading a context object through every call.
# ---------------------------------------------------------------------------
$script:MyIDSocket         = $null
$script:MyIDTimeoutSeconds = 120

# The card list does NOT arrive inside the ShowSelectCardView stage. Instead the
# stage carries a `cardsChangedEventMessageId` that points at a separate
# `CardsChangedEvent` (type 'EventNotification'). That event may arrive before or
# after the stage, so we cache every event we see here, keyed by its eventId.
$script:MyIDEventsById = @{}

# How many lines the last busy message occupied, so the next one can paint over
# it. Zero means nothing is currently on screen.
$script:MyIDBusyLines = 0


function Connect-MyIDClient {
	<#
		.SYNOPSIS
			Opens a WebSocket to the local MyID client.

		.DESCRIPTION
			The endpoint shape is  ws://<host>:<port>/v<version>/myidclient
			Note the version comes FIRST and is prefixed with 'v'.

			The Origin header must be in the client's WS-AllowedOrigins config,
			or the connection is rejected with 403.
	#>
	[CmdletBinding()]
	param(
		[string] $HostName       = 'localhost',
		[int]    $Port           = 1337,
		[string] $Origin         = 'http://localhost',
		[string] $ApiVersion     = '1.x',
		[switch] $UseTls,
		[int]    $TimeoutSeconds = 120
	)

	$scheme = if ($UseTls) { 'wss' } else { 'ws' }
	$uri    = "${scheme}://${HostName}:${Port}/v${ApiVersion}/myidclient"

	$socket = [ClientWebSocket]::new()
	$socket.Options.SetRequestHeader('Origin', $Origin)

	Write-Verbose "Connecting to $uri"
	try {
		# .GetAwaiter().GetResult() runs the async call synchronously. ConnectAsync
		# returns a void Task, so assign to $null to keep it off the pipeline.
		$null = $socket.ConnectAsync([uri] $uri, [System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
	}
	catch {
		throw "Could not connect to $uri. Check the MyID client is running, the port is correct, " +
			  "and that '$Origin' is listed in WS-AllowedOrigins. Underlying error: $($_.Exception.Message)"
	}

	$script:MyIDSocket         = $socket
	$script:MyIDTimeoutSeconds = $TimeoutSeconds
	$script:MyIDEventsById     = @{}
	$script:MyIDBusyLines      = 0
}


function Disconnect-MyIDClient {
	Clear-MyIDBusyLine

	if ($null -ne $script:MyIDSocket) {
		if ($script:MyIDSocket.State -eq [WebSocketState]::Open) {
			$null = $script:MyIDSocket.CloseAsync([WebSocketCloseStatus]::NormalClosure, 'Done',
				[System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
		}
		$script:MyIDSocket.Dispose()
		$script:MyIDSocket = $null
	}
}


# ---------------------------------------------------------------------------
# Mask secrets so verbose output is safe to paste into a bug report.
# ---------------------------------------------------------------------------
function ConvertTo-MyIDRedactedJson {
	param([string] $Json)

	foreach ($key in @('pin', 'newPin', 'oldPin', 'token', 'client_secret', 'access_token')) {
		$Json = [regex]::Replace($Json, "(""$key""\s*:\s*)""[^""]*""", '$1"***"')
	}
	return $Json
}


function Send-MyIDMessage {
	<#
		.SYNOPSIS
			Sends a message envelope.

		.DESCRIPTION
			Every message is a JSON "envelope": always an `action`, optionally a
			`routingId` (to answer a specific stage) and a `payload`.
	#>
	param(
		[Parameter(Mandatory)] [string] $Action,
		[string]    $RoutingId,
		[hashtable] $Payload,
		[string]    $CorrelationId
	)

	$envelope = [ordered] @{ action = $Action }
	if ($RoutingId)     { $envelope.routingId     = $RoutingId }
	if ($CorrelationId) { $envelope.correlationId = $CorrelationId }
	if ($Payload)       { $envelope.payload       = $Payload }

	$json = $envelope | ConvertTo-Json -Depth 10 -Compress
	Write-Verbose "--> $(ConvertTo-MyIDRedactedJson $json)"

	$bytes   = [System.Text.Encoding]::UTF8.GetBytes($json)
	$segment = [ArraySegment[byte]]::new($bytes)
	$null = $script:MyIDSocket.SendAsync($segment, [WebSocketMessageType]::Text, $true,
		[System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
}


function Send-MyIDStageReply {
	<#
		.SYNOPSIS
			Replies to a specific open stage.

		.DESCRIPTION
			routingId is mandatory on any message targeting a stage; without it
			the message is simply not delivered.
	#>
	param(
		[Parameter(Mandatory)] $Stage,
		[Parameter(Mandatory)] [string] $Action,
		[hashtable] $Payload
	)

	Send-MyIDMessage -Action $Action -RoutingId $Stage.routingId -Payload $Payload
}


function Receive-MyIDMessage {
	<#
		.SYNOPSIS
			Receives one message envelope, or $null if the client closed the
			connection.

		.DESCRIPTION
			Simplified: assumes the whole message fits in one 16 KB frame. The
			real module reassembles fragmented frames.
	#>
	$buffer = [ArraySegment[byte]]::new([byte[]]::new(16384))
	$cts    = [System.Threading.CancellationTokenSource]::new([timespan]::FromSeconds($script:MyIDTimeoutSeconds))
	try {
		$result = $script:MyIDSocket.ReceiveAsync($buffer, $cts.Token).GetAwaiter().GetResult()
	}
	catch [System.OperationCanceledException] {
		throw "Timed out after $($script:MyIDTimeoutSeconds)s waiting for a message from the MyID client."
	}
	finally {
		$cts.Dispose()
	}

	if ($result.MessageType -eq [WebSocketMessageType]::Close) { return $null }

	$json = [System.Text.Encoding]::UTF8.GetString($buffer.Array, 0, $result.Count)
	Write-Verbose "<-- $(ConvertTo-MyIDRedactedJson $json)"
	return $json | ConvertFrom-Json
}


function Test-MyIDProperty {
	param($Object, [string] $Name)
	return ($null -ne $Object) -and ($Object.PSObject.Properties.Name -contains $Name)
}


function Get-MyIDPayload {
	<#
		.SYNOPSIS
			Returns a message's payload, or $null when it has none.

		.DESCRIPTION
			Not every message carries a payload - HideBusyMessage is the common
			case - and under Set-StrictMode touching the missing property is a
			terminating error rather than $null.
	#>
	param($Message)

	if (Test-MyIDProperty $Message 'payload') { return $Message.payload }
	return $null
}


# ---------------------------------------------------------------------------
# Busy messages.
#
# MyID streams progress as it works. Rather than letting those messages scroll
# past, we paint the latest one in place and rub it out again when the workflow
# moves on. Verbose runs skip this entirely: the raw message log is more useful
# there, and cursor movement would scramble it.
#
# Naive by design - this is a tutorial. A message wider than the terminal will
# soft-wrap onto a second physical line that the cursor-up count doesn't know
# about, leaving a stray line behind.
# ---------------------------------------------------------------------------
function Clear-MyIDBusyLine {
	if ($VerbosePreference -ne 'SilentlyContinue') { return }
	if ($script:MyIDBusyLines -le 0) { return }

	# `e[1A moves up a line, `e[2K erases it.
	for ($i = 0; $i -lt $script:MyIDBusyLines; $i++) {
		[Console]::Write("`e[1A`e[2K")
	}
	$script:MyIDBusyLines = 0
}


function Write-MyIDBusyMessage {
	param($Payload)

	if ($VerbosePreference -ne 'SilentlyContinue') {
		if (Test-MyIDProperty $Payload 'primaryBusyMessage') {
			Write-Verbose "Busy: $($Payload.primaryBusyMessage)"
		}
		return
	}

	Clear-MyIDBusyLine

	$lines = @()
	if (Test-MyIDProperty $Payload 'primaryBusyMessage') {
		$lines += $Payload.primaryBusyMessage
	}

	# Assumed layout: the tertiary messages are sub-steps of the primary one,
	# so we indent them beneath it. They were never populated in the traces
	# these samples were written against.
	if (Test-MyIDProperty $Payload 'tertiaryBusyMessages') {
		foreach ($tertiary in @($Payload.tertiaryBusyMessages)) {
			if (-not [string]::IsNullOrWhiteSpace($tertiary)) { $lines += "  $tertiary" }
		}
	}

	foreach ($line in $lines) { Write-Host $line }
	$script:MyIDBusyLines = $lines.Count
}


function Wait-MyIDEvent {
	<#
		.SYNOPSIS
			Waits for an EventNotification with the given eventId, returning its
			payload. Returns immediately if the event has already been seen.
	#>
	param([Parameter(Mandatory)] [string] $EventId)

	if ($script:MyIDEventsById.ContainsKey($EventId)) { return $script:MyIDEventsById[$EventId] }

	while ($true) {
		$msg = Receive-MyIDMessage
		if ($null -eq $msg) { throw 'The client closed the connection while waiting for an event.' }

		if ($msg.type -eq 'EventNotification' -and (Test-MyIDProperty $msg 'eventId')) {
			$payload = Get-MyIDPayload $msg
			$script:MyIDEventsById[$msg.eventId] = $payload
			if ($msg.eventId -eq $EventId) { return $payload }
		}
	}
}


function Get-MyIDSelectableCard {
	<#
		.SYNOPSIS
			Resolves the card list for a ShowSelectCardView stage and returns the
			card with the requested serial number.

		.DESCRIPTION
			The card list is not delivered once and for all. MyID emits a
			CardsChangedEvent whenever readers come and go, reusing the same
			eventId, so the card you want may only appear in a later update -
			for example a virtual smart card that takes a moment to enumerate.
			We therefore keep watching until the named card shows up.

			The card is never chosen for you: issuing to the wrong credential is
			not something a sample should do silently.

		.PARAMETER SerialNumber
			The serial number of the card to issue to. Matched
			case-insensitively, since serials are rendered as hex.
	#>
	param(
		[Parameter(Mandatory)] $Stage,
		[Parameter(Mandatory)] [string] $SerialNumber,
		[int] $TimeoutSeconds = 60
	)

	$stagePayload = Get-MyIDPayload $Stage
	if (-not (Test-MyIDProperty $stagePayload 'cardsChangedEventMessageId')) {
		throw 'The select-card stage did not name a card-list event; cannot enumerate cards.'
	}

	$eventId  = $stagePayload.cardsChangedEventMessageId
	$wanted   = $SerialNumber.Trim()
	$deadline = [datetime]::UtcNow.AddSeconds($TimeoutSeconds)
	$payload  = Wait-MyIDEvent -EventId $eventId
	$seen     = @()

	while ($true) {
		# `validForSelection` marks cards the workflow will actually accept.
		# Anything else is shown greyed-out in a real UI; here we simply drop it.
		$cards = @()
		if (Test-MyIDProperty $payload 'cards') {
			$cards = @($payload.cards | Where-Object {
				-not (Test-MyIDProperty $_ 'validForSelection') -or $_.validForSelection
			})
		}

		$seen = @($cards | ForEach-Object { $_.serialNumber })

		$card = $cards | Where-Object { $_.serialNumber -ieq $wanted } | Select-Object -First 1
		if ($null -ne $card) { return $card }

		if ([datetime]::UtcNow -ge $deadline) { break }

		Write-Verbose "Card '$wanted' not offered yet; waiting for the list to change. Currently: $($seen -join ', ')"

		# Wait for the next revision of the same card list.
		$updated = $false
		while (-not $updated) {
			if ([datetime]::UtcNow -ge $deadline) { break }

			$msg = Receive-MyIDMessage
			if ($null -eq $msg) { throw 'The client closed the connection while waiting for a card.' }

			if ($msg.type -eq 'EventNotification' -and (Test-MyIDProperty $msg 'eventId')) {
				$msgPayload = Get-MyIDPayload $msg
				$script:MyIDEventsById[$msg.eventId] = $msgPayload
				if ($msg.eventId -eq $eventId) {
					$payload = $msgPayload
					$updated = $true
				}
			}
		}

		if (-not $updated) { break }
	}

	if ($seen.Count -eq 0) {
		throw "No suitable smartcard was detected within ${TimeoutSeconds}s. Insert the card and try again."
	}

	throw "Card '$SerialNumber' was not offered within ${TimeoutSeconds}s. Available: $($seen -join ', ')"
}


function Invoke-MyIDWorkflow {
	<#
		.SYNOPSIS
			Starts an initial action and pumps messages until the workflow ends.

		.DESCRIPTION
			Returns the WorkflowComplete payload. Throws on ApiError,
			ActionError, ShowErrorView, an unexpected stage, or an unexpected
			close.

		.PARAMETER StageHandlers
			Hashtable mapping a stage action name to a scriptblock. The
			scriptblock receives the stage message as $args[0] and should either
			reply itself (via Send-MyIDStageReply) or return nothing if the
			stage advances on its own.
	#>
	[CmdletBinding()]
	param(
		[Parameter(Mandatory)] [string] $InitialAction,
		[hashtable] $InitialPayload,
		[Parameter(Mandatory)] [hashtable] $StageHandlers
	)

	Send-MyIDMessage -Action $InitialAction -Payload $InitialPayload -CorrelationId ([guid]::NewGuid().ToString())

	while ($true) {
		$message = Receive-MyIDMessage
		if ($null -eq $message) {
			Clear-MyIDBusyLine
			throw 'The client closed the connection before the workflow finished.'
		}

		$type    = if (Test-MyIDProperty $message 'type') { $message.type } else { $null }
		$payload = Get-MyIDPayload $message

		switch ($type) {

			'ShowStage' {
				# Any stage means MyID is waiting on us, so the busy block is done.
				Clear-MyIDBusyLine

				# ShowErrorView is a workflow-level failure. Surface the MyID
				# error code and message rather than letting the loop stall.
				if ($message.action -eq 'ShowErrorView') {
					$code = if (Test-MyIDProperty $payload 'errorCode')    { $payload.errorCode }    else { 'no code' }
					$text = if (Test-MyIDProperty $payload 'errorMessage') { $payload.errorMessage } else { 'The workflow reported an error.' }
					throw "MyID reported an error: $text ($code)"
				}

				$handler = $StageHandlers[$message.action]
				if ($null -eq $handler) {
					throw "Unexpected stage '$($message.action)'. This sample only handles: " +
						  "$(($StageHandlers.Keys | Sort-Object) -join ', '). " +
						  'Check the credential profile configuration.'
				}

				& $handler $message
			}

			'EventNotification' {
				if (Test-MyIDProperty $message 'eventId') {
					$script:MyIDEventsById[$message.eventId] = $payload
				}
			}

			'BusyStateChangedNotification' {
				# HideBusyMessage carries no payload at all.
				if ($message.action -eq 'HideBusyMessage') {
					Clear-MyIDBusyLine
				}
				else {
					Write-MyIDBusyMessage $payload
				}
			}

			'Error' {
				Clear-MyIDBusyLine

				# ApiError   - the request itself was invalid.
				# ActionError - the stage is still open and a corrected reply
				#               could be sent; these samples don't retry.
				$code = if (Test-MyIDProperty $payload 'errorCode') { $payload.errorCode } else { 'unknown error' }
				throw "$($message.action): $code"
			}

			'WorkflowControl' {
				if ($message.action -eq 'WorkflowComplete') {
					Clear-MyIDBusyLine

					if ((Test-MyIDProperty $payload 'success') -and $payload.success) {
						return $payload
					}

					$text = if (Test-MyIDProperty $payload 'errorMessage') { $payload.errorMessage } else { $null }
					throw "The workflow did not complete successfully. $text".Trim()
				}
			}

			default {
				# AlertNotification, ConnectionControl and unsolicited
				# StageAction responses are ignored by these samples.
			}
		}
	}
}
