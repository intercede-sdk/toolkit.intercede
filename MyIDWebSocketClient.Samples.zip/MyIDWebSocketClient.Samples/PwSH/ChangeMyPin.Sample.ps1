#Requires -Version 7.0

<#
	ChangeMyPin.Sample.ps1
	======================

	An ULTRA-SIMPLIFIED example of changing the PIN on an existing MyID card
	from PowerShell, written to be read top-to-bottom as a tutorial.

	This is the non-interactive counterpart to ChangeMyPin.Sample.html: every
	value is supplied up front as a parameter, so the script can run unattended.

	Unlike the collection samples there is no token to obtain. Change My PIN is
	started with WORKFLOWWITHEMBEDDEDAUTH, naming the operation directly and
	letting the card itself authenticate the cardholder - which is why the
	current PIN is a parameter rather than something the Core API issues.

	The WebSocket plumbing lives in lib/MyIDWebSocket.ps1, shared with the other
	samples; read that file for the protocol details.

	This sample assumes the operation runs:

		busy -> select card -> card PIN logon -> set new PIN -> busy -> done

	Any other stage is reported as an error rather than silently ignored, so if
	your system adds a stage you will be told exactly which one turned up.

	This is deliberately NOT production code - see the header of
	lib/MyIDWebSocket.ps1 for the list of things it leaves out on purpose.

	Run it like:
		.\ChangeMyPin.Sample.ps1 -User jbloggs -SerialNumber ABC123 `
			-CurrentPin 123456 -NewPin 654321 -Verbose

	If you don't know the serial number, run with a placeholder: the error
	lists every card MyID offered.
#>

[CmdletBinding()]
param(
	# The MyID logon name of the cardholder whose PIN is being changed.
	[Parameter(Mandatory)] [string] $User,

	# Serial number of the card to change. Mandatory: the sample will not
	# guess, even when only one card is present. Run with an unknown value to
	# have the error list every card MyID offered.
	[Parameter(Mandatory)] [string] $SerialNumber,

	# The card's current PIN, used to authenticate the cardholder to the card.
	[Parameter(Mandatory)] [string] $CurrentPin,

	# The PIN to set. Must satisfy the PIN policy, which is reported under
	# -Verbose before the new PIN is submitted.
	[Parameter(Mandatory)] [string] $NewPin,

	# Automatically accept selection prompts by taking the first option. MyID
	# raises one of these when a device type isn't fully configured, which is
	# common on a test system. Off by default, so the sample never silently
	# accepts something you'd want to see.
	[switch] $AcceptPrompts,

	# The MyID operation to run. 202 is Change My PIN; it is a parameter only
	# so the sample can be pointed at a differently configured system.
	[int] $OperationId = 202,

	# Switch to this MyID server before starting. Optional.
	[string] $ServerAddress,

	[string] $HostName       = 'localhost',
	[int]    $Port           = 1337,
	[string] $Origin         = 'http://localhost',
	[string] $ApiVersion     = '1.x',
	[int]    $TimeoutSeconds = 300
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Clear-Host

. (Join-Path $PSScriptRoot 'lib/MyIDWebSocket.ps1')

# ---------------------------------------------------------------------------
# The stage handlers for a PIN change.
#
# Each handler receives the ShowStage message and replies on that stage's
# routingId. They are non-interactive: every value is supplied up front.
# ---------------------------------------------------------------------------
$stageHandlers = @{

	# Pick the card. The card list does not arrive with the stage - it comes as
	# a separate CardsChangedEvent, which Get-MyIDSelectableCard resolves. That
	# list is revised as readers come and go, so the helper keeps watching until
	# the requested card appears.
	#
	# The reply must carry BOTH serialNumber AND deviceTypeName; sending the
	# serial on its own is rejected with SelectedDeviceInvalid.
	'ShowSelectCardView' = {
		param($stage)

		$card = Get-MyIDSelectableCard -Stage $stage -SerialNumber $SerialNumber
		Write-Verbose "Changing the PIN on card $($card.serialNumber)."

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{
			serialNumber   = $card.serialNumber
			deviceTypeName = $card.deviceTypeName
		}
	}

	# Authenticate to the card with the current PIN. This is the "embedded
	# auth" the initial action asked for: the card, not the server, verifies
	# the cardholder.
	#
	# A wrong PIN comes back as an ActionError with the stage still open. This
	# sample does not retry, so it surfaces as a terminating error - be aware
	# that repeated attempts will eventually lock the card.
	'ShowCardPinLogonView' = {
		param($stage)

		Write-Verbose 'Authenticating to the card with the current PIN.'
		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{ pin = $CurrentPin }
	}

	# Choose the new PIN.
	#
	# A production client would first send CheckPinPolicy (non-terminal) to
	# validate the PIN against $stage.payload.pinPolicyItems before committing.
	# Here we just submit it and let an ActionError tell us if it is rejected.
	'ShowNewPinView' = {
		param($stage)

		$payload = Get-MyIDPayload $stage
		if (Test-MyIDProperty $payload 'pinPolicyItems') {
			Write-Verbose "PIN policy: $($payload.pinPolicyItems -join '; ')"
		}

		Write-Verbose 'Setting the new PIN.'
		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{ newPin = $NewPin }
	}

	# A generic "pick one of these" prompt. MyID uses it for confirmations that
	# aren't errors -- notably the warning raised when a device type isn't fully
	# configured, which is normal on a test system but blocks the operation
	# until something is chosen.
	'ShowSelectItemView' = {
		param($stage)

		$payload = Get-MyIDPayload $stage
		$title   = if (Test-MyIDProperty $payload 'title') { $payload.title } else { '' }
		$body    = if (Test-MyIDProperty $payload 'body')  { $payload.body }  else { '' }
		$items   = if (Test-MyIDProperty $payload 'items') { @($payload.items) } else { @() }

		if ($items.Count -eq 0) {
			throw "MyID asked for a selection but offered no options. Title: '$title'. Body: '$body'"
		}

		Write-Host "MyID asks: $(($title, $body | Where-Object { $_ }) -join ' - ')" -ForegroundColor Yellow
		Write-Verbose "Options: $(($items | ForEach-Object { "$($_.id)=$($_.text)" }) -join ', ')"

		if (-not $AcceptPrompts) {
			throw "MyID is prompting for a choice: '$title $body'. Options: " +
				  "$(($items | ForEach-Object { $_.text }) -join ', '). " +
				  'Re-run with -AcceptPrompts to accept the first option automatically.'
		}

		$chosen = $items[0]
		Write-Host "Accepting: $($chosen.text)" -ForegroundColor Yellow

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{
			selectedOptionId = $chosen.id
		}
	}
}

# ---------------------------------------------------------------------------
# Run it.
#
# WORKFLOWWITHEMBEDDEDAUTH names the operation and the user directly. Contrast
# WORKFLOWFROMTOKEN in the collection samples, where a token carries that
# metadata instead.
# ---------------------------------------------------------------------------
try {
	Connect-MyIDClient -HostName $HostName -Port $Port -Origin $Origin `
		-ApiVersion $ApiVersion -TimeoutSeconds $TimeoutSeconds

	$payload = @{
		user        = $User
		operationid = $OperationId
	}
	if ($ServerAddress) { $payload.serverAddress = $ServerAddress }

	Write-Host "Changing the PIN for $User..."
	$null = Invoke-MyIDWorkflow -InitialAction 'WORKFLOWWITHEMBEDDEDAUTH' `
		-InitialPayload $payload -StageHandlers $stageHandlers

	Write-Host 'PIN changed successfully.' -ForegroundColor Green
}
finally {
	Disconnect-MyIDClient
}
