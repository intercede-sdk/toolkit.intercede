#Requires -Version 7.0

<#
	CollectJobFromToken.Sample.ps1
	==============================

	An ULTRA-SIMPLIFIED example of collecting a pending MyID job from
	PowerShell, written to be read top-to-bottom as a tutorial.

	The MyID logon token is supplied directly, as a parameter. The token is what
	identifies the work to be done: it carries the metadata describing the
	operation and the job, which is why the WORKFLOWFROMTOKEN payload only needs
	{ token }.

	See RequestAndCollectJob.Sample.ps1 for the variant that talks to the MyID
	Core API to request the card and mint the token for you.

	The WebSocket plumbing lives in lib/MyIDWebSocket.ps1 so both samples share
	it; read that file for the protocol details.

	This sample assumes a credential profile configured so that collection runs:

		busy -> select card -> busy -> set new PIN -> busy -> done

	Any other stage is reported as an error rather than silently ignored, so if
	your profile adds (say) security phrases you will be told exactly which
	stage turned up.

	This is deliberately NOT production code - see the header of
	lib/MyIDWebSocket.ps1 for the list of things it leaves out on purpose.

	Run it like:
		.\CollectJobFromToken.Sample.ps1 -Token '<myid-token>' -NewPin 123456 -Verbose

	Or, if more than one card is present:
		.\CollectJobFromToken.Sample.ps1 -Token '<myid-token>' -NewPin 123456 `
			-SerialNumber ABC123 -Verbose
#>

[CmdletBinding()]
param(
	# The MyID logon token. Carries the operation and job metadata.
	[Parameter(Mandatory)] [string] $Token,

	# The PIN to set on the newly issued card.
	[Parameter(Mandatory)] [string] $NewPin,

	# Serial number of the card to issue to. Mandatory: the sample will not
	# guess, even when only one card is present. Run with an unknown value to
	# have the error list every card MyID offered.
	[Parameter(Mandatory)] [string] $SerialNumber,

	# Automatically accept selection prompts by taking the first option. MyID
	# raises one of these when a device type isn't fully configured, which is
	# common on a test system. Off by default, so the sample never silently
	# accepts something you'd want to see.
	[switch] $AcceptPrompts,

	# Switch to this MyID server before starting. Optional.
	[string] $ServerAddress,

	[string] $HostName       = 'localhost',
	[int]    $Port           = 1337,
	[string] $Origin         = 'http://localhost',
	[string] $ApiVersion     = '1.x',
	[int]    $TimeoutSeconds = 300
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Clear-Host

. (Join-Path $PSScriptRoot 'lib/MyIDWebSocket.ps1')

# ---------------------------------------------------------------------------
# The stage handlers for a collection.
#
# Each handler receives the ShowStage message and replies on that stage's
# routingId. They are non-interactive: every value is supplied up front.
# ---------------------------------------------------------------------------
$stageHandlers = @{

	# Pick a smartcard. The card list does not arrive with the stage - it comes
	# as a separate CardsChangedEvent, which Get-MyIDSelectableCard resolves.
	'ShowSelectCardView' = {
		param($stage)

		$card = Get-MyIDSelectableCard -Stage $stage -SerialNumber $SerialNumber
		Write-Verbose "Collecting onto card $($card.serialNumber)."

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{
			serialNumber   = $card.serialNumber
			deviceTypeName = $card.deviceTypeName
		}
	}

	# Choose the new PIN for the freshly issued card.
	#
	# A production client would first send CheckPinPolicy (non-terminal) to
	# validate the PIN against $stage.payload.pinPolicyItems before committing.
	# Here we just submit it and let an ActionError tell us if it is rejected.
	'ShowNewPinView' = {
		param($stage)

		$payload = Get-MyIDPayload $stage
		if (Test-MyIDProperty $payload 'pinPolicyItems') {
			Write-Verbose "PIN policy: $($payload.pinPolicyItems -join '; ')"
		}

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{ newPin = $NewPin }
	}

	# A generic "pick one of these" prompt. MyID uses it for confirmations that
	# aren't errors -- notably the warning raised when a device type isn't fully
	# configured, which is normal on a test system but blocks collection until
	# something is chosen.
	'ShowSelectItemView' = {
		param($stage)

		$payload = Get-MyIDPayload $stage
		$title   = if (Test-MyIDProperty $payload 'title') { $payload.title } else { '' }
		$body    = if (Test-MyIDProperty $payload 'body')  { $payload.body }  else { '' }
		$items   = if (Test-MyIDProperty $payload 'items') { @($payload.items) } else { @() }

		if ($items.Count -eq 0) {
			throw "MyID asked for a selection but offered no options. Title: '$title'. Body: '$body'"
		}

		Write-Host "MyID asks: $(($title, $body | Where-Object { $_ }) -join ' - ')" -ForegroundColor Yellow
		Write-Verbose "Options: $(($items | ForEach-Object { "$($_.id)=$($_.text)" }) -join ', ')"

		if (-not $AcceptPrompts) {
			throw "MyID is prompting for a choice: '$title $body'. Options: " +
				  "$(($items | ForEach-Object { $_.text }) -join ', '). " +
				  'Re-run with -AcceptPrompts to accept the first option automatically.'
		}

		$chosen = $items[0]
		Write-Host "Accepting: $($chosen.text)" -ForegroundColor Yellow

		Send-MyIDStageReply -Stage $stage -Action 'Continue' -Payload @{
			selectedOptionId = $chosen.id
		}
	}
}

# ---------------------------------------------------------------------------
# Run it.
# ---------------------------------------------------------------------------
try {
	Connect-MyIDClient -HostName $HostName -Port $Port -Origin $Origin `
		-ApiVersion $ApiVersion -TimeoutSeconds $TimeoutSeconds

	$payload = @{ token = $Token }
	if ($ServerAddress) { $payload.serverAddress = $ServerAddress }

	Write-Host 'Starting the collection...'
	$null = Invoke-MyIDWorkflow -InitialAction 'WORKFLOWFROMTOKEN' `
		-InitialPayload $payload -StageHandlers $stageHandlers

	Write-Host 'Card collected successfully.' -ForegroundColor Green
}
finally {
	Disconnect-MyIDClient
}
